import React, { useState } from 'react';
import { X, Lock, Unlock, ShieldAlert, KeyRound, AlertCircle, Sparkles, Mail } from 'lucide-react';

interface OwnerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: () => void;
}

export default function OwnerAuthModal({ isOpen, onClose, onAuthSuccess }: OwnerAuthModalProps) {
  const [passkey, setPasskey] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Acceptable passkeys - Only the owner's email is allowed
    const validPasskeys = [
      'aalhyari2009@gmail.com'
    ];

    if (validPasskeys.includes(passkey.trim().toLowerCase())) {
      onAuthSuccess();
      onClose();
      setPasskey('');
    } else {
      setError('البريد الإلكتروني المدخل غير مصرح به لولوج لوحة الإعلانات!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in text-right" dir="rtl" id="owner-auth-modal">
      <div className="relative w-full max-w-md bg-slate-900 border-2 border-indigo-500/30 rounded-[32px] shadow-2xl overflow-hidden p-6 md:p-8 animate-scale-in">
        
        {/* Background Decorative glow */}
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-lg text-white">بوابة المالك والتحقق الأمني</h3>
              <p className="text-[10px] text-indigo-400 font-bold">تسجيل الدخول لتعديل إعدادات الإعلانات</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 bg-red-500/10 border border-red-500/20 text-red-400 text-xs px-3.5 py-2.5 rounded-xl font-bold flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-slate-400 font-bold mb-1.5">البريد الإلكتروني للمالك: *</label>
            <div className="relative">
              <Mail className="absolute right-3 top-2.5 w-4 h-4 text-indigo-400" />
              <input
                type="email"
                required
                value={passkey}
                onChange={(e) => setPasskey(e.target.value)}
                placeholder="أدخل بريدك الإلكتروني هنا..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 pr-9 text-xs text-white placeholder-slate-650 outline-none transition-all text-center font-mono"
              />
            </div>
          </div>

          <div className="bg-indigo-950/40 border border-indigo-500/10 p-3.5 rounded-2xl text-[11px] text-indigo-300 leading-relaxed space-y-1.5">
            <div className="flex items-center gap-1 font-bold text-indigo-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>معلومات مهمة للمالك:</span>
            </div>
            <p>
              بصفتك المالك المصرح له، تم تشفير لوحة الإعلانات بالكامل وتأمينها لمنع الزوار من الوصول إليها أو العبث بالمعرفات الربحية الخاصة بك.
            </p>
            <p className="font-bold text-slate-400">
              🔒 الدخول متاح وحصري فقط للبريد الإلكتروني المعتمد الخاص بك.
            </p>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs py-3 rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-500/10 active:scale-[0.98]"
            >
              التحقق والدخول للبوابة 🔑
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
