import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, Play, HelpCircle } from 'lucide-react';

interface MemoryGameProps {
  bestMoves: number;
  onUpdateBestMoves: (moves: number) => void;
}

interface Card {
  id: number;
  emoji: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const EMOJIS = ['🎮', '🕹️', '🎯', '🧩', '🎲', '👾', '🚀', '🏆'];

export default function MemoryGame({ bestMoves, onUpdateBestMoves }: MemoryGameProps) {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [isWon, setIsWon] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const initGame = () => {
    // Duplicate emojis and shuffle them
    const doubled = [...EMOJIS, ...EMOJIS];
    const shuffled = doubled
      .map((emoji, index) => ({ id: index, emoji, isFlipped: false, isMatched: false }))
      .sort(() => Math.random() - 0.5);

    setCards(shuffled);
    setFlippedIndices([]);
    setMoves(0);
    setIsWon(false);
    setIsPlaying(true);
  };

  const handleCardClick = (clickedIndex: number) => {
    if (!isPlaying || isWon) return;
    
    const card = cards[clickedIndex];
    if (card.isFlipped || card.isMatched) return;

    // Limit to 2 cards flipped at once
    if (flippedIndices.length >= 2) return;

    // Flip the clicked card
    const updatedCards = [...cards];
    updatedCards[clickedIndex].isFlipped = true;
    setCards(updatedCards);

    const newFlipped = [...flippedIndices, clickedIndex];
    setFlippedIndices(newFlipped);

    // If this is the second card flipped, check for match
    if (newFlipped.length === 2) {
      setMoves(prev => prev + 1);
      const [firstIdx, secondIdx] = newFlipped;
      
      if (cards[firstIdx].emoji === cards[secondIdx].emoji) {
        // It's a match!
        setTimeout(() => {
          const matchedCards = [...cards];
          matchedCards[firstIdx].isMatched = true;
          matchedCards[secondIdx].isMatched = true;
          setCards(matchedCards);
          setFlippedIndices([]);

          // Check if all matched
          const won = matchedCards.every(c => c.isMatched);
          if (won) {
            setIsWon(true);
            setIsPlaying(false);
            if (bestMoves === 0 || moves + 1 < bestMoves) {
              onUpdateBestMoves(moves + 1);
            }
          }
        }, 600);
      } else {
        // No match, flip them back
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[firstIdx].isFlipped = false;
          resetCards[secondIdx].isFlipped = false;
          setCards(resetCards);
          setFlippedIndices([]);
        }, 1000);
      }
    }
  };

  useEffect(() => {
    initGame();
  }, []);

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-md mx-auto" id="memory-game-container">
      {/* Stats Board */}
      <div className="flex items-center justify-between w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2">
          <RotateCcw className="w-5 h-5 text-indigo-400" />
          <div>
            <p className="text-[10px] text-gray-400">عدد المحاولات</p>
            <p className="text-xl font-bold font-mono text-indigo-400">{moves}</p>
          </div>
        </div>
        <div className="text-center bg-slate-950 px-4 py-1.5 rounded-xl border border-slate-800/60">
          <p className="text-[10px] text-gray-500 font-medium">الهدف</p>
          <p className="text-xs text-slate-300">طابق كل الرموز المتشابهة</p>
        </div>
        <div className="flex items-center gap-2 text-right">
          <div>
            <p className="text-[10px] text-gray-400">أفضل محاولة (أقل حركات)</p>
            <p className="text-xl font-bold font-mono text-amber-400">{bestMoves || '-'}</p>
          </div>
          <Award className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Grid Container */}
      <div className="relative w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="grid grid-cols-4 gap-3 aspect-square">
          {cards.map((card, index) => {
            const isRevealed = card.isFlipped || card.isMatched;
            return (
              <button
                key={card.id}
                onClick={() => handleCardClick(index)}
                className={`relative flex items-center justify-center rounded-xl transition-all duration-500 transform cursor-pointer border select-none [perspective:1000px] h-full w-full aspect-square ${
                  card.isMatched
                    ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400 scale-[0.98]'
                    : isRevealed
                    ? 'bg-slate-800 border-indigo-500 text-white rotate-y-180'
                    : 'bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 text-gray-500 hover:border-indigo-500/50 hover:scale-[1.02]'
                }`}
              >
                {/* 3D Flipping Effect container */}
                <div className="flex items-center justify-center w-full h-full text-2xl md:text-3xl font-bold transition-transform duration-300">
                  {isRevealed ? (
                    card.emoji
                  ) : (
                    <HelpCircle className="w-6 h-6 text-indigo-400/60 animate-pulse" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Victory/Not started Overlay */}
        {(!isPlaying || isWon) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-6 text-center">
            {isWon ? (
              <div className="space-y-4">
                <span className="text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full text-xs font-semibold">
                  رائع! نصر ساحق
                </span>
                <h3 className="text-2xl font-black text-white">طابقت جميع البطاقات!</h3>
                <p className="text-sm text-gray-400">
                  أنهيت اللعبة في غضون <span className="text-indigo-400 font-bold font-mono text-lg">{moves}</span> حركة.
                </p>
                <button
                  onClick={initGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-indigo-500/15 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  العب مجدداً
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <h3 className="text-2xl font-black text-white">لعبة مطابقة الرموز الثنائية</h3>
                <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
                  اختبر قوة ذاكرتك! انقر على البطاقات للعثور على الأزواج المتطابقة في أقل عدد ممكن من الحركات.
                </p>
                <button
                  onClick={initGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-indigo-500/15 cursor-pointer"
                >
                  <Play className="w-4 h-4" />
                  ابدأ جولة جديدة
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Manual Restart */}
      {isPlaying && !isWon && (
        <button
          onClick={initGame}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          إعادة تعيين اللعبة
        </button>
      )}
    </div>
  );
}
