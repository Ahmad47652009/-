import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Award, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

interface SnakeGameProps {
  highScore: number;
  onUpdateHighScore: (score: number) => void;
}

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
type Position = { x: number; y: number };

export default function SnakeGame({ highScore, onUpdateHighScore }: SnakeGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  
  // Game state refs to prevent re-render issues in intervals
  const snakeRef = useRef<Position[]>([{ x: 10, y: 10 }]);
  const foodRef = useRef<Position>({ x: 5, y: 5 });
  const directionRef = useRef<Direction>('RIGHT');
  const gameLoopRef = useRef<number | null>(null);
  
  const gridSize = 20;
  const tileCount = 20; // 20 * 20 = 400px canvas size (adjusted dynamically via style)

  // Initialize and Reset Game
  const resetGame = () => {
    snakeRef.current = [
      { x: 10, y: 10 },
      { x: 9, y: 10 },
      { x: 8, y: 10 },
    ];
    directionRef.current = 'RIGHT';
    setScore(0);
    setIsGameOver(false);
    setIsPlaying(true);
    generateFood();
  };

  const generateFood = () => {
    let newFood: Position;
    let isOnSnake = true;
    while (isOnSnake) {
      newFood = {
        x: Math.floor(Math.random() * tileCount),
        y: Math.floor(Math.random() * tileCount),
      };
      // Check if food coordinates land on snake body
      isOnSnake = snakeRef.current.some(part => part.x === newFood.x && part.y === newFood.y);
    }
    foodRef.current = newFood!;
  };

  // Keyboard Event Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isGameOver) return;
      
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          if (directionRef.current !== 'DOWN') directionRef.current = 'UP';
          e.preventDefault();
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          if (directionRef.current !== 'UP') directionRef.current = 'DOWN';
          e.preventDefault();
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          if (directionRef.current !== 'RIGHT') directionRef.current = 'LEFT';
          e.preventDefault();
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          if (directionRef.current !== 'LEFT') directionRef.current = 'RIGHT';
          e.preventDefault();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isGameOver]);

  // Game Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      return;
    }

    const moveSnake = () => {
      const head = { ...snakeRef.current[0] };

      switch (directionRef.current) {
        case 'UP': head.y -= 1; break;
        case 'DOWN': head.y += 1; break;
        case 'LEFT': head.x -= 1; break;
        case 'RIGHT': head.x += 1; break;
      }

      // Check boundary collisions
      if (head.x < 0 || head.x >= tileCount || head.y < 0 || head.y >= tileCount) {
        handleGameOver();
        return;
      }

      // Check self collision
      if (snakeRef.current.some((part, i) => i > 0 && part.x === head.x && part.y === head.y)) {
        handleGameOver();
        return;
      }

      // Move snake head forward
      const newSnake = [head, ...snakeRef.current];

      // Check food consumption
      if (head.x === foodRef.current.x && head.y === foodRef.current.y) {
        setScore(prev => {
          const next = prev + 10;
          if (next > highScore) {
            onUpdateHighScore(next);
          }
          return next;
        });
        generateFood();
      } else {
        newSnake.pop(); // Remove tail
      }

      snakeRef.current = newSnake;
      drawGame();
    };

    // Game loop speed scales slightly with score
    const speed = Math.max(130 - Math.floor(score / 50) * 10, 70);
    gameLoopRef.current = window.setInterval(moveSnake, speed);

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
    };
  }, [isPlaying, isGameOver, score, highScore]);

  // Draw Game onto Canvas
  const drawGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear board with dark gaming aesthetic background
    ctx.fillStyle = '#0f172a'; // slate-900
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw Grid Lines (Subtle)
    ctx.strokeStyle = '#1e293b'; // slate-800
    ctx.lineWidth = 0.5;
    for (let i = 0; i < tileCount; i++) {
      ctx.beginPath();
      ctx.moveTo(i * gridSize, 0);
      ctx.lineTo(i * gridSize, canvas.height);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i * gridSize);
      ctx.lineTo(canvas.width, i * gridSize);
      ctx.stroke();
    }

    // Draw Food (Neon Target)
    const fx = foodRef.current.x * gridSize;
    const fy = foodRef.current.y * gridSize;
    ctx.fillStyle = '#ef4444'; // red-500
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(fx + gridSize / 2, fy + gridSize / 2, gridSize / 2.5, 0, 2 * Math.PI);
    ctx.fill();
    ctx.shadowBlur = 0; // Reset shadow

    // Draw Snake
    snakeRef.current.forEach((part, index) => {
      const isHead = index === 0;
      const px = part.x * gridSize;
      const py = part.y * gridSize;

      // Color gradient or custom colors
      if (isHead) {
        ctx.fillStyle = '#10b981'; // emerald-500
        ctx.shadowColor = '#10b981';
        ctx.shadowBlur = 10;
      } else {
        // Body fade effect
        ctx.fillStyle = `rgba(16, 185, 129, ${Math.max(1 - index * 0.05, 0.4)})`;
      }

      // Draw rounded tile
      const radius = isHead ? 6 : 4;
      ctx.beginPath();
      ctx.roundRect(px + 1, py + 1, gridSize - 2, gridSize - 2, radius);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Eyes on head
      if (isHead) {
        ctx.fillStyle = '#ffffff';
        // Position eyes depending on direction
        let eye1 = { x: 0, y: 0 };
        let eye2 = { x: 0, y: 0 };
        
        switch (directionRef.current) {
          case 'RIGHT':
            eye1 = { x: px + 12, y: py + 5 };
            eye2 = { x: px + 12, y: py + 13 };
            break;
          case 'LEFT':
            eye1 = { x: px + 6, y: py + 5 };
            eye2 = { x: px + 6, y: py + 13 };
            break;
          case 'UP':
            eye1 = { x: px + 5, y: py + 6 };
            eye2 = { x: px + 13, y: py + 6 };
            break;
          case 'DOWN':
            eye1 = { x: px + 5, y: py + 12 };
            eye2 = { x: px + 13, y: py + 12 };
            break;
        }
        ctx.beginPath();
        ctx.arc(eye1.x, eye1.y, 1.5, 0, 2 * Math.PI);
        ctx.arc(eye2.x, eye2.y, 1.5, 0, 2 * Math.PI);
        ctx.fill();
      }
    });
  };

  const handleGameOver = () => {
    setIsGameOver(true);
    setIsPlaying(false);
  };

  // Run initial draw so canvas isn't empty
  useEffect(() => {
    drawGame();
  }, []);

  // Button Direction Controller (for mobile or pointer users)
  const changeDirection = (newDir: Direction) => {
    if (!isPlaying || isGameOver) return;
    const current = directionRef.current;
    if (newDir === 'UP' && current !== 'DOWN') directionRef.current = 'UP';
    if (newDir === 'DOWN' && current !== 'UP') directionRef.current = 'DOWN';
    if (newDir === 'LEFT' && current !== 'RIGHT') directionRef.current = 'LEFT';
    if (newDir === 'RIGHT' && current !== 'LEFT') directionRef.current = 'RIGHT';
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-lg mx-auto" id="snake-game-container">
      {/* Game Stats */}
      <div className="flex items-center justify-between w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2">
          <Award className="w-5 h-5 text-emerald-400" />
          <div>
            <p className="text-[10px] text-gray-400">النقاط الحالية</p>
            <p className="text-xl font-bold font-mono text-emerald-400">{score}</p>
          </div>
        </div>
        <div className="text-center bg-slate-950 px-4 py-1.5 rounded-xl border border-slate-800/60">
          <p className="text-[10px] text-gray-500 font-medium">طريقة اللعب</p>
          <p className="text-xs text-slate-300">استخدم الأسهم أو أزرار التوجيه</p>
        </div>
        <div className="flex items-center gap-2 text-right">
          <div>
            <p className="text-[10px] text-gray-400">أعلى نتيجة</p>
            <p className="text-xl font-bold font-mono text-amber-400">{highScore}</p>
          </div>
          <Award className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Canvas Area */}
      <div className="relative border-4 border-slate-800 rounded-2xl overflow-hidden bg-slate-950 shadow-2xl w-full aspect-square max-w-[400px]">
        <canvas
          ref={canvasRef}
          width={400}
          height={400}
          className="w-full h-full block"
        />

        {/* Not Playing overlay */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            {isGameOver ? (
              <div className="space-y-4">
                <span className="text-red-500 bg-red-500/10 border border-red-500/20 px-3 py-1 rounded-full text-xs font-semibold">
                  انتهت اللعبة!
                </span>
                <h3 className="text-2xl font-black text-white">لقد خسرت الجولة</h3>
                <p className="text-sm text-gray-400">مجموع نقاطك الكلي: <span className="text-emerald-400 font-bold font-mono text-lg">{score}</span> نقطة</p>
                <button
                  onClick={resetGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-emerald-500/15 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  العب مجدداً
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <h3 className="text-2xl font-black text-white">لعبة الثعبان الكلاسيكية</h3>
                <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
                  التقط الكرات الحمراء لتكبر وتكسب النقاط. تجنب الاصطدام بالحواف أو الاصطدام بجسمك!
                </p>
                <button
                  onClick={resetGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-emerald-500/15 cursor-pointer"
                >
                  <Play className="w-4 h-4" />
                  ابدأ اللعب الآن
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* D-Pad controls for mobile / ease of play */}
      <div className="flex flex-col items-center gap-2 w-full max-w-[200px] mt-2">
        <button
          onClick={() => changeDirection('UP')}
          className="w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-white rounded-xl shadow-lg border border-slate-700 transition-all cursor-pointer"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
        <div className="flex gap-10">
          <button
            onClick={() => changeDirection('LEFT')}
            className="w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-white rounded-xl shadow-lg border border-slate-700 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => changeDirection('RIGHT')}
            className="w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-white rounded-xl shadow-lg border border-slate-700 transition-all cursor-pointer"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
        <button
          onClick={() => changeDirection('DOWN')}
          className="w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-white rounded-xl shadow-lg border border-slate-700 transition-all cursor-pointer"
        >
          <ArrowDown className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
