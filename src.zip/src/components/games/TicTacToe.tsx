import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, User, Bot, HelpCircle } from 'lucide-react';

interface TicTacToeProps {
  wins: number;
  onUpdateWins: (wins: number) => void;
}

type BoardState = (string | null)[];

export default function TicTacToe({ wins, onUpdateWins }: TicTacToeProps) {
  const [board, setBoard] = useState<BoardState>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);
  const [gameMode, setGameMode] = useState<'ai' | 'local'>('ai'); // ai or local 2p
  const [aiDifficulty, setAiDifficulty] = useState<'easy' | 'smart'>('smart');
  const [winner, setWinner] = useState<string | null>(null);
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [isDraw, setIsDraw] = useState(false);
  const [playerSymbol, setPlayerSymbol] = useState<'X' | 'O'>('X');

  const WINNING_COMBOS = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6]             // Diagonals
  ];

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
    setWinner(null);
    setWinningLine(null);
    setIsDraw(false);
  };

  // Check winner on board change
  useEffect(() => {
    let currentWinner: string | null = null;
    let combo: number[] | null = null;

    for (const line of WINNING_COMBOS) {
      const [a, b, c] = line;
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        currentWinner = board[a];
        combo = line;
        break;
      }
    }

    if (currentWinner) {
      setWinner(currentWinner);
      setWinningLine(combo);
      
      // Update high scores only if the player won
      if (gameMode === 'ai' && currentWinner === playerSymbol) {
        onUpdateWins(wins + 1);
      }
    } else if (board.every(cell => cell !== null)) {
      setIsDraw(true);
    }
  }, [board]);

  // AI Move triggered if it is AI's turn
  useEffect(() => {
    if (gameMode !== 'ai' || winner || isDraw) return;

    // AI is 'O' if player is 'X', and 'X' if player is 'O'
    const aiSymbol = playerSymbol === 'X' ? 'O' : 'X';
    const isAiTurn = (isXNext && playerSymbol === 'O') || (!isXNext && playerSymbol === 'X');

    if (isAiTurn) {
      const timer = setTimeout(() => {
        const bestMove = getAiMove(board, aiSymbol, playerSymbol);
        if (bestMove !== -1) {
          makeMove(bestMove);
        }
      }, 500); // Small artificial delay for immersion
      return () => clearTimeout(timer);
    }
  }, [board, isXNext, gameMode, playerSymbol, winner, isDraw]);

  const makeMove = (index: number) => {
    if (board[index] || winner || isDraw) return;

    const newBoard = [...board];
    newBoard[index] = isXNext ? 'X' : 'O';
    setBoard(newBoard);
    setIsXNext(!isXNext);
  };

  // Heuristic / Minimax-like AI rules
  const getAiMove = (tempBoard: BoardState, ai: string, player: string): number => {
    // 1. Easy: Choose random open space
    if (aiDifficulty === 'easy') {
      const emptyIndices = tempBoard.map((c, idx) => c === null ? idx : -1).filter(idx => idx !== -1);
      return emptyIndices.length > 0 ? emptyIndices[Math.floor(Math.random() * emptyIndices.length)] : -1;
    }

    // Smart Strategy:
    // A. Win: If there is a line with two AI symbols and one empty, take it.
    for (const combo of WINNING_COMBOS) {
      const [a, b, c] = combo;
      const vals = [tempBoard[a], tempBoard[b], tempBoard[c]];
      const aiCount = vals.filter(v => v === ai).length;
      const emptyCount = vals.filter(v => v === null).length;
      if (aiCount === 2 && emptyCount === 1) {
        if (tempBoard[a] === null) return a;
        if (tempBoard[b] === null) return b;
        if (tempBoard[c] === null) return c;
      }
    }

    // B. Block: If there is a line with two Player symbols and one empty, take it.
    for (const combo of WINNING_COMBOS) {
      const [a, b, c] = combo;
      const vals = [tempBoard[a], tempBoard[b], tempBoard[c]];
      const playerCount = vals.filter(v => v === player).length;
      const emptyCount = vals.filter(v => v === null).length;
      if (playerCount === 2 && emptyCount === 1) {
        if (tempBoard[a] === null) return a;
        if (tempBoard[b] === null) return b;
        if (tempBoard[c] === null) return c;
      }
    }

    // C. Take Center if available
    if (tempBoard[4] === null) return 4;

    // D. Take Corners
    const corners = [0, 2, 6, 8];
    const emptyCorners = corners.filter(idx => tempBoard[idx] === null);
    if (emptyCorners.length > 0) {
      return emptyCorners[Math.floor(Math.random() * emptyCorners.length)];
    }

    // E. Take remaining edges
    const edges = [1, 3, 5, 7];
    const emptyEdges = edges.filter(idx => tempBoard[idx] === null);
    if (emptyEdges.length > 0) {
      return emptyEdges[Math.floor(Math.random() * emptyEdges.length)];
    }

    return -1;
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-sm mx-auto" id="tictactoe-container">
      {/* Game Mode Controls */}
      <div className="flex flex-col gap-3 w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <span className="text-xs text-gray-400 font-medium">الخصم والمستويات</span>
          <div className="flex gap-2">
            <button
              onClick={() => { setGameMode('ai'); resetGame(); }}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                gameMode === 'ai' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' : 'bg-slate-950 text-gray-400'
              }`}
            >
              الذكاء الاصطناعي
            </button>
            <button
              onClick={() => { setGameMode('local'); resetGame(); }}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                gameMode === 'local' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' : 'bg-slate-950 text-gray-400'
              }`}
            >
              لاعبان (محلي)
            </button>
          </div>
        </div>

        {gameMode === 'ai' && (
          <div className="flex justify-between items-center pt-1">
            <span className="text-xs text-gray-400">مستوى الصعوبة</span>
            <div className="flex gap-1.5">
              <button
                onClick={() => setAiDifficulty('easy')}
                className={`px-2.5 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                  aiDifficulty === 'easy' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-950 text-gray-500'
                }`}
              >
                سهل
              </button>
              <button
                onClick={() => setAiDifficulty('smart')}
                className={`px-2.5 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                  aiDifficulty === 'smart' ? 'bg-red-500/20 text-red-400' : 'bg-slate-950 text-gray-500'
                }`}
              >
                ذكي جداً
              </button>
            </div>
          </div>
        )}

        <div className="flex justify-between items-center pt-2 border-t border-slate-800/60">
          <span className="text-xs text-gray-400">رمز اللاعب الخاص بك</span>
          <div className="flex gap-1.5">
            <button
              onClick={() => { setPlayerSymbol('X'); resetGame(); }}
              className={`px-3 py-0.5 rounded font-mono text-xs font-bold transition-colors cursor-pointer ${
                playerSymbol === 'X' ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-950 text-gray-500'
              }`}
            >
              X
            </button>
            <button
              onClick={() => { setPlayerSymbol('O'); resetGame(); }}
              className={`px-3 py-0.5 rounded font-mono text-xs font-bold transition-colors cursor-pointer ${
                playerSymbol === 'O' ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-950 text-gray-500'
              }`}
            >
              O
            </button>
          </div>
        </div>
      </div>

      {/* Stats Board */}
      <div className="flex items-center justify-between w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2">
          {gameMode === 'ai' ? <Bot className="w-5 h-5 text-indigo-400" /> : <User className="w-5 h-5 text-indigo-400" />}
          <div>
            <p className="text-[10px] text-gray-400">الدور الحالي</p>
            <p className="text-sm font-bold text-white">
              {isXNext ? 'اللاعب X' : 'اللاعب O'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-right">
          <div>
            <p className="text-[10px] text-gray-400">الفوز ضد الذكاء</p>
            <p className="text-xl font-bold font-mono text-amber-400">{wins}</p>
          </div>
          <Award className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Grid Board */}
      <div className="relative w-full aspect-square bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="grid grid-cols-3 gap-3 h-full">
          {board.map((cell, index) => {
            const isWinningCell = winningLine?.includes(index);
            return (
              <button
                key={index}
                onClick={() => makeMove(index)}
                disabled={cell !== null || winner !== null || isDraw}
                className={`relative flex items-center justify-center rounded-xl transition-all duration-300 transform font-mono text-4xl font-extrabold select-none border h-full cursor-pointer ${
                  isWinningCell
                    ? 'bg-amber-500/10 border-amber-500 text-amber-400 scale-[1.02] shadow-lg shadow-amber-500/10'
                    : cell === 'X'
                    ? 'bg-blue-950/20 border-blue-500/30 text-blue-400'
                    : cell === 'O'
                    ? 'bg-rose-950/20 border-rose-500/30 text-rose-400'
                    : 'bg-slate-900/60 border-slate-800 text-transparent hover:border-slate-700 hover:bg-slate-850/60'
                }`}
              >
                {cell}
              </button>
            );
          })}
        </div>

        {/* Overlay for game status (winner or draw) */}
        {(winner || isDraw) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-6 text-center">
            {winner ? (
              <div className="space-y-4">
                <span className="text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full text-xs font-semibold">
                  مبـروك! انتهت الجولة
                </span>
                <h3 className="text-2xl font-black text-white">
                  {winner === playerSymbol && gameMode === 'ai' ? 'لقد انتصرت!' : `فاز اللاعب ${winner}`}
                </h3>
                <p className="text-xs text-gray-400 max-w-xs">
                  {winner === playerSymbol && gameMode === 'ai'
                    ? 'تفوّقت على الذكاء الاصطناعي بنجاح مذهل!'
                    : 'جولة رائعة ومثيرة.'}
                </p>
                <button
                  onClick={resetGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-amber-500/15 cursor-pointer mx-auto"
                >
                  <RotateCcw className="w-4 h-4" />
                  جولة جديدة
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <span className="text-gray-400 bg-slate-800 border border-slate-700 px-3 py-1 rounded-full text-xs font-semibold">
                  تعـادل!
                </span>
                <h3 className="text-2xl font-black text-white">لا يوجد فائز</h3>
                <p className="text-xs text-gray-400 max-w-xs">
                  لقد استنفدت جميع الخانات دون حسم النتيجة.
                </p>
                <button
                  onClick={resetGame}
                  className="flex items-center gap-2 bg-slate-850 hover:bg-slate-850/90 text-white font-semibold py-2.5 px-6 rounded-xl border border-slate-700 transition-all duration-300 transform hover:scale-[1.03] cursor-pointer mx-auto"
                >
                  <RotateCcw className="w-4 h-4" />
                  إعادة المحاولة
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Manual Reset */}
      {(board.some(c => c !== null) || winner || isDraw) && (
        <button
          onClick={resetGame}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          تصفير اللوحة
        </button>
      )}
    </div>
  );
}
