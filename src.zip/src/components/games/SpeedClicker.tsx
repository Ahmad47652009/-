import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Award, Heart, Sparkles } from 'lucide-react';

interface SpeedClickerProps {
  highScore: number;
  onUpdateHighScore: (score: number) => void;
}

interface Meteor {
  id: number;
  x: number;
  y: number;
  radius: number;
  speed: number;
  color: string;
  points: number;
  glow: string;
}

export default function SpeedClicker({ highScore, onUpdateHighScore }: SpeedClickerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);

  const meteorsRef = useRef<Meteor[]>([]);
  const animationFrameRef = useRef<number | null>(null);
  const meteorIdCounter = useRef(0);
  const spawnTimerRef = useRef<number | null>(null);

  const resetGame = () => {
    meteorsRef.current = [];
    setScore(0);
    setLives(3);
    setIsGameOver(false);
    setIsPlaying(true);
    meteorIdCounter.current = 0;
  };

  const handleGameOver = () => {
    setIsGameOver(true);
    setIsPlaying(false);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (spawnTimerRef.current) clearInterval(spawnTimerRef.current);
  };

  // Click on Canvas handler
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPlaying || isGameOver) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    // Scale click position to match high-DPI canvas coordinates
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    // Filter meteors and check if clicked inside radius
    let hitAny = false;
    const remainingMeteors = meteorsRef.current.filter(meteor => {
      const distance = Math.hypot(meteor.x - clickX, meteor.y - clickY);
      const isHit = distance <= meteor.radius + 15; // Generous hit area for easy touch/clicks
      
      if (isHit) {
        hitAny = true;
        setScore(prev => {
          const next = prev + meteor.points;
          if (next > highScore) {
            onUpdateHighScore(next);
          }
          return next;
        });
      }
      return !isHit;
    });

    meteorsRef.current = remainingMeteors;
  };

  // Spawn Meteor Function
  const spawnMeteor = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const radius = Math.random() * 15 + 12; // 12px to 27px
    const x = Math.random() * (canvas.width - radius * 2) + radius;
    const y = -radius;
    
    // Choose properties based on difficulty/score
    const randomVal = Math.random();
    let color = '#ec4899'; // default pink
    let glow = '#ec4899';
    let points = 10;
    let speed = Math.random() * 2 + 1.5 + (score / 150); // Speed scales up with score

    if (randomVal > 0.85) {
      // Golden Golden meteor (Double Points)
      color = '#f59e0b';
      glow = '#fbbf24';
      points = 25;
      speed += 1.2;
    } else if (randomVal > 0.65) {
      // Fast blue meteor
      color = '#06b6d4';
      glow = '#22d3ee';
      points = 15;
      speed += 0.8;
    }

    const newMeteor: Meteor = {
      id: meteorIdCounter.current++,
      x,
      y,
      radius,
      speed,
      color,
      points,
      glow,
    };

    meteorsRef.current.push(newMeteor);
  };

  // Game Animation Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      // Background with translucent overlay for smooth movement trails
      ctx.fillStyle = 'rgba(15, 23, 42, 0.25)'; // slate-900 with alpha
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw subtle stars
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      for (let i = 0; i < 8; i++) {
        const starX = (Math.sin(i * 350 + score) + 1) * (canvas.width / 2);
        const starY = (Math.cos(i * 120) + 1) * (canvas.height / 2);
        ctx.fillRect(starX, starY, 1.5, 1.5);
      }

      // Update and Draw Meteors
      const activeMeteors: Meteor[] = [];
      let missedMeteors = 0;

      meteorsRef.current.forEach(meteor => {
        meteor.y += meteor.speed;

        // Check if meteor exited at bottom
        if (meteor.y - meteor.radius > canvas.height) {
          missedMeteors++;
        } else {
          activeMeteors.push(meteor);

          // Draw Meteor
          ctx.beginPath();
          ctx.shadowColor = meteor.glow;
          ctx.shadowBlur = 15;
          ctx.fillStyle = meteor.color;
          ctx.arc(meteor.x, meteor.y, meteor.radius, 0, Math.PI * 2);
          ctx.fill();

          // Draw texture details inside meteor
          ctx.beginPath();
          ctx.shadowBlur = 0;
          ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
          ctx.arc(meteor.x - meteor.radius / 4, meteor.y - meteor.radius / 4, meteor.radius / 3, 0, Math.PI * 2);
          ctx.fill();

          ctx.beginPath();
          ctx.arc(meteor.x + meteor.radius / 3, meteor.y + meteor.radius / 4, meteor.radius / 4, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      meteorsRef.current = activeMeteors;

      // Handle missed meteors
      if (missedMeteors > 0) {
        setLives(prev => {
          const next = prev - missedMeteors;
          if (next <= 0) {
            handleGameOver();
            return 0;
          }
          return next;
        });
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    // Spawn meteors periodically
    // Spawning interval gets shorter as the score increases
    const spawnRate = Math.max(1200 - Math.floor(score / 40) * 80, 500);
    spawnTimerRef.current = window.setInterval(spawnMeteor, spawnRate);

    // Start frame loop
    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (spawnTimerRef.current) clearInterval(spawnTimerRef.current);
    };
  }, [isPlaying, isGameOver, score]);

  // Initial Clean Render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0f172a'; // slate-900
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-md mx-auto" id="speedclicker-container">
      {/* Stats Board */}
      <div className="flex items-center justify-between w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-1">
          <Sparkles className="w-5 h-5 text-pink-400" />
          <div>
            <p className="text-[10px] text-gray-400">النقاط</p>
            <p className="text-lg font-bold font-mono text-pink-400">{score}</p>
          </div>
        </div>

        {/* Lives counter */}
        <div className="flex gap-1 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800/60">
          {[...Array(3)].map((_, i) => (
            <Heart
              key={i}
              className={`w-4 h-4 transition-colors ${
                i < lives ? 'fill-red-500 text-red-500' : 'text-gray-700'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center gap-2 text-right">
          <div>
            <p className="text-[10px] text-gray-400">أعلى نتيجة</p>
            <p className="text-lg font-bold font-mono text-amber-400">{highScore}</p>
          </div>
          <Award className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Canvas Block */}
      <div className="relative border-4 border-slate-800 rounded-2xl overflow-hidden bg-slate-950 shadow-2xl w-full aspect-[4/5] max-w-[400px]">
        <canvas
          ref={canvasRef}
          width={400}
          height={500}
          onClick={handleCanvasClick}
          className="w-full h-full block cursor-crosshair touch-none"
        />

        {/* Game State Overlays */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            {isGameOver ? (
              <div className="space-y-4">
                <span className="text-red-500 bg-red-500/10 border border-red-500/20 px-3 py-1 rounded-full text-xs font-semibold">
                  تحطم الكوكب!
                </span>
                <h3 className="text-2xl font-black text-white">تحطمت آخر الدفاعات</h3>
                <p className="text-sm text-gray-400">
                  لقد حصدت <span className="text-pink-400 font-bold font-mono text-lg">{score}</span> نقطة قبل السقوط!
                </p>
                <button
                  onClick={resetGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-pink-500/15 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  أعد محاولة الدفاع
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-full bg-pink-500/10 border border-pink-500/30 flex items-center justify-center mx-auto shadow-inner">
                  <Sparkles className="w-6 h-6 text-pink-400 animate-pulse" />
                </div>
                <h3 className="text-2xl font-black text-white">لعبة صائد النيازك</h3>
                <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
                  أنقذ مدينتك! انقر على النيازك الملونة المنهارة لتفجيرها قبل هبوطها إلى أسفل الشاشة.
                </p>
                <div className="grid grid-cols-2 gap-2 max-w-xs text-[10px] text-gray-400 border border-slate-800 p-2 rounded-lg bg-slate-900/40">
                  <div>🟡 نيزك ذهبي: <span className="text-amber-400 font-bold">25 نقطة</span></div>
                  <div>🔵 نيزك سريع: <span className="text-cyan-400 font-bold">15 نقطة</span></div>
                </div>
                <button
                  onClick={resetGame}
                  className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white font-bold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-[1.03] shadow-lg shadow-pink-500/15 cursor-pointer mx-auto"
                >
                  <Play className="w-4 h-4" />
                  ابدأ الدفاع الجوي
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Manual Restart */}
      {isPlaying && !isGameOver && (
        <button
          onClick={resetGame}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          إعادة التشغيل
        </button>
      )}
    </div>
  );
}
