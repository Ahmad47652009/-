import React, { useState } from 'react';
import { Comment, GameId } from '../types';
import { Star, MessageSquare, Send, Trash2, Calendar, User } from 'lucide-react';

interface GameCommentsProps {
  gameId: GameId;
  comments: Comment[];
  onAddComment: (comment: Omit<Comment, 'id' | 'createdAt'>) => void;
  onDeleteComment?: (id: string) => void;
}

export default function GameComments({ gameId, comments, onAddComment, onDeleteComment }: GameCommentsProps) {
  const [username, setUsername] = useState('');
  const [text, setText] = useState('');
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [error, setError] = useState('');

  // Filter comments for this game
  const filteredComments = comments.filter(c => c.gameId === gameId);

  // Compute stats
  const totalComments = filteredComments.length;
  const averageRating = totalComments
    ? (filteredComments.reduce((sum, c) => sum + c.rating, 0) / totalComments).toFixed(1)
    : '0.0';

  const ratingCounts = [0, 0, 0, 0, 0]; // Index 0 for 1 star, Index 4 for 5 stars
  filteredComments.forEach(c => {
    const idx = Math.min(Math.max(c.rating - 1, 0), 4);
    ratingCounts[idx]++;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim()) {
      setError('يرجى إدخال اسم المستخدم!');
      return;
    }
    if (!text.trim()) {
      setError('يرجى كتابة التعليق الخاص بك!');
      return;
    }

    onAddComment({
      gameId,
      username: username.trim(),
      rating,
      text: text.trim(),
    });

    // Reset fields except username for easier subsequent entries if desired
    setText('');
    setRating(5);
  };

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 shadow-xl mt-8 text-right" id="game-comments-container" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5 mb-6">
        <div>
          <h3 className="text-xl font-black text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-400" />
            <span>آراء وتقييمات اللاعبين</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">شاركنا رأيك وتجربتك للعبة مع اللاعبين الآخرين</p>
        </div>
        
        {/* Rating Stats Overview */}
        <div className="flex items-center gap-3 bg-slate-950/40 px-4 py-2 rounded-2xl border border-slate-800/80">
          <div className="text-center">
            <div className="text-2xl font-black text-indigo-400 font-mono leading-none">{averageRating}</div>
            <div className="text-[10px] text-slate-500 font-bold mt-0.5">من 5 نجوم</div>
          </div>
          <div className="h-8 w-px bg-slate-800"></div>
          <div>
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  className={`w-3.5 h-3.5 ${
                    s <= Math.round(Number(averageRating))
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-slate-600'
                  }`}
                />
              ))}
            </div>
            <div className="text-[10px] text-slate-400 font-bold mt-0.5">({totalComments} تقييم)</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Comment Form */}
        <div className="lg:col-span-5 bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 space-y-4">
          <h4 className="font-bold text-sm text-indigo-400 border-b border-slate-800/60 pb-2">إضافة تقييم جديد</h4>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs px-3 py-2 rounded-xl font-bold">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-400 font-bold mb-2">اسم المستخدم:</label>
              <div className="relative">
                <User className="absolute right-3.5 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="مثال: أحمد المحارب"
                  maxLength={25}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-4 pr-10 text-xs text-white placeholder-slate-600 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 font-bold mb-2">تقييمك بالنجوم:</label>
              <div className="flex items-center gap-1.5 bg-slate-900/50 p-2.5 rounded-xl border border-slate-800/50 justify-center">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setRating(s)}
                    onMouseEnter={() => setHoverRating(s)}
                    onMouseLeave={() => setHoverRating(null)}
                    className="p-1 hover:scale-125 transition-transform cursor-pointer"
                  >
                    <Star
                      className={`w-6 h-6 transition-colors ${
                        s <= (hoverRating ?? rating)
                          ? 'fill-yellow-400 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.2)]'
                          : 'text-slate-600 hover:text-slate-500'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 font-bold mb-2 font-sans">التعليق أو المراجعة:</label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="اكتب انطباعك عن اللعبة، نقاط القوة، ومقترحاتك للتطوير..."
                rows={3}
                maxLength={250}
                className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-3 text-xs text-white placeholder-slate-600 outline-none transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-500/10 active:scale-[0.98]"
            >
              <Send className="w-4 h-4 rotate-180" />
              <span>إرسال التعليق والتقييم</span>
            </button>
          </form>
        </div>

        {/* Comments List */}
        <div className="lg:col-span-7 space-y-4">
          <h4 className="font-bold text-sm text-indigo-400 border-b border-slate-800/60 pb-2">
            مراجعات اللاعبين ({totalComments})
          </h4>

          {filteredComments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 bg-slate-950/20 border border-dashed border-slate-800 rounded-2xl text-center">
              <div className="w-12 h-12 rounded-full bg-slate-900 flex items-center justify-center text-slate-600 border border-slate-800 mb-3">
                <MessageSquare className="w-5 h-5 text-slate-500" />
              </div>
              <p className="text-xs text-slate-400 font-bold">لا توجد تعليقات بعد لهذه اللعبة.</p>
              <p className="text-[11px] text-slate-500 mt-1">كن أول من يكتب مراجعته وتجربته الخاصة!</p>
            </div>
          ) : (
            <div className="space-y-3.5 max-h-[380px] overflow-y-auto pr-1">
              {filteredComments.map((comment) => (
                <div
                  key={comment.id}
                  className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all flex flex-col gap-2.5 relative group"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-black shadow-md shadow-indigo-500/10">
                        {comment.username.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-xs font-black text-slate-200">{comment.username}</div>
                        <div className="flex gap-0.5 mt-0.5">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-2.5 h-2.5 ${
                                s <= comment.rating
                                  ? 'fill-yellow-400 text-yellow-400'
                                  : 'text-slate-700'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 text-[10px] text-slate-500">
                        <Calendar className="w-3 h-3" />
                        <span>{comment.createdAt}</span>
                      </div>
                      
                      {onDeleteComment && (
                        <button
                          onClick={() => onDeleteComment(comment.id)}
                          className="text-red-500/60 hover:text-red-400 p-1 rounded-lg hover:bg-red-500/10 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer duration-250"
                          title="حذف التعليق"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed font-sans bg-slate-950/20 p-2.5 rounded-xl border border-slate-800/40">
                    {comment.text}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
