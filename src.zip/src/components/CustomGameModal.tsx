import React, { useState } from 'react';
import { Game } from '../types';
import { X, Gamepad2, Sparkles, AlertCircle, Link2, User, Smile } from 'lucide-react';

interface CustomGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGame: (game: Game) => void;
}

const CATEGORIES = [
  { ar: 'أركيد', en: 'Arcade' },
  { ar: 'ذكاء', en: 'Puzzle' },
  { ar: 'استراتيجية', en: 'Strategy' },
  { ar: 'أكشن وسرعة', en: 'Action' },
  { ar: 'مغامرات', en: 'Adventure' },
  { ar: 'رياضة', en: 'Sports' }
];

const EMOJIS = ['👾', '🚀', '🏎️', '🎯', '🔮', '⚔️', '🏀', '🧟', '🕹️', '🧱', '🎈', '🦖', '🌟', '🛡️', '🧪'];

export default function CustomGameModal({ isOpen, onClose, onAddGame }: CustomGameModalProps) {
  const [titleAr, setTitleAr] = useState('');
  const [descAr, setDescAr] = useState('');
  const [categoryAr, setCategoryAr] = useState('أركيد');
  const [difficulty, setDifficulty] = useState<'سهل' | 'متوسط' | 'صعب'>('متوسط');
  const [customUrl, setCustomUrl] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [icon, setIcon] = useState('👾');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!titleAr.trim()) {
      setError('يرجى إدخال اسم اللعبة بالعربية!');
      return;
    }
    if (!descAr.trim()) {
      setError('يرجى إدخال وصف اللعبة بالعربية!');
      return;
    }
    if (!authorName.trim()) {
      setError('يرجى إدخال اسم المطور المصمم!');
      return;
    }

    // Optional URL validation
    if (customUrl.trim() && !customUrl.startsWith('http://') && !customUrl.startsWith('https://')) {
      setError('يرجى إدخال رابط صحيح يبدأ بـ http:// أو https://');
      return;
    }

    const selectedCategoryObj = CATEGORIES.find(c => c.ar === categoryAr);
    const categoryEn = selectedCategoryObj ? selectedCategoryObj.en : 'Arcade';

    const newGame: Game = {
      id: `custom_${Date.now()}`,
      titleAr: titleAr.trim(),
      titleEn: titleAr.trim(), // fallback
      descAr: descAr.trim(),
      descEn: descAr.trim(), // fallback
      icon,
      categoryAr,
      categoryEn,
      difficulty,
      isCustom: true,
      customUrl: customUrl.trim() || undefined,
      authorName: authorName.trim(),
    };

    onAddGame(newGame);
    onClose();

    // Reset fields
    setTitleAr('');
    setDescAr('');
    setCustomUrl('');
    setAuthorName('');
    setIcon('👾');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in text-right" dir="rtl" id="custom-game-modal">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-indigo-500/30 rounded-[32px] shadow-2xl overflow-hidden p-6 md:p-8 animate-scale-in">
        
        {/* Background Decorative glow */}
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-lg text-white">إطلاق ونشر لعبتك الخاصة</h3>
              <p className="text-[10px] text-indigo-400 font-bold">اعرض تصميمك وإبداعك للآلاف من محبي الألعاب!</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 bg-red-500/10 border border-red-500/20 text-red-400 text-xs px-3.5 py-2.5 rounded-xl font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-400 font-bold mb-1.5">اسم اللعبة: *</label>
              <div className="relative">
                <Gamepad2 className="absolute right-3 top-2.5 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  required
                  value={titleAr}
                  onChange={(e) => setTitleAr(e.target.value)}
                  placeholder="مثال: سباق النجوم"
                  maxLength={30}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 pr-9 text-xs text-white placeholder-slate-600 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 font-bold mb-1.5">المصمم / المطور: *</label>
              <div className="relative">
                <User className="absolute right-3 top-2.5 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  required
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  placeholder="مثال: المهندس يزن"
                  maxLength={25}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 pr-9 text-xs text-white placeholder-slate-600 outline-none transition-all"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-400 font-bold mb-1.5">التصنيف الرئيسي:</label>
              <select
                value={categoryAr}
                onChange={(e) => setCategoryAr(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 text-xs text-white outline-none transition-all cursor-pointer"
              >
                {CATEGORIES.map(c => (
                  <option key={c.ar} value={c.ar}>{c.ar}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-400 font-bold mb-1.5">مستوى الصعوبة:</label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 text-xs text-white outline-none transition-all cursor-pointer"
              >
                <option value="سهل">سهل</option>
                <option value="متوسط">متوسط</option>
                <option value="صعب">صعب</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 font-bold mb-1.5">رابط اللعبة المضمن (اختياري - يدعم Scratch, Itch, HTML5):</label>
            <div className="relative">
              <Link2 className="absolute right-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="url"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://scratch.mit.edu/projects/embed/..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 pr-9 text-xs text-white placeholder-slate-650 outline-none transition-all text-left"
                dir="ltr"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">إذا تركت الرابط فارغاً، فسيقوم محركنا التفاعلي بإنشاء منصة أركيد ممتعة ومميزة للعبتك تلقائياً!</p>
          </div>

          {/* Emoji Selector */}
          <div>
            <label className="block text-xs text-slate-400 font-bold mb-1.5 flex items-center gap-1">
              <Smile className="w-3.5 h-3.5 text-indigo-400" />
              <span>اختر الأيقونة المميزة للعبة:</span>
            </label>
            <div className="flex flex-wrap gap-2 bg-slate-950/60 p-3 rounded-2xl border border-slate-800/60">
              {EMOJIS.map(em => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setIcon(em)}
                  className={`w-10 h-10 rounded-xl text-xl flex items-center justify-center transition-all cursor-pointer hover:bg-slate-800 ${
                    icon === em
                      ? 'bg-indigo-600/30 border-2 border-indigo-500 text-white scale-110 shadow-md shadow-indigo-500/10'
                      : 'bg-slate-900 border border-slate-800/80 text-slate-300'
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 font-bold mb-1.5">وصف اللعبة وطريقة اللعب: *</label>
            <textarea
              required
              value={descAr}
              onChange={(e) => setDescAr(e.target.value)}
              placeholder="اكتب كيف يفوز اللاعب، ما هي الأزرار المستخدمة، والهدف من لعبتك الخاصة..."
              rows={3}
              maxLength={200}
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-3 text-xs text-white placeholder-slate-600 outline-none transition-all resize-none"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs py-3 rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-500/10 active:scale-[0.98]"
            >
              نشر اللعبة فوراً 🚀
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
