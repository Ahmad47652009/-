import React, { useEffect, useState } from 'react';
import { Shield, Sparkles, AlertCircle, Info } from 'lucide-react';

interface GoogleAdProps {
  client: string;
  slot: string;
  format?: 'auto' | 'fluid' | 'rectangle' | 'vertical' | 'horizontal';
  isResponsive?: boolean;
  isDemoMode: boolean;
  adType: 'leaderboard' | 'skyscraper' | 'rectangle' | 'responsive';
}

export default function GoogleAd({
  client,
  slot,
  format = 'auto',
  isResponsive = true,
  isDemoMode,
  adType,
}: GoogleAdProps) {
  const [adBlockedOrFailed, setAdBlockedOrFailed] = useState(false);
  const [adLoaded, setAdLoaded] = useState(false);

  // Dynamic script loader for real Google AdSense
  useEffect(() => {
    if (isDemoMode) return;

    // Check if script already exists
    const existingScript = document.querySelector(
      'script[src*="pagead2.googlesyndication.com"]'
    );

    if (!existingScript && client) {
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${client}`;
      script.async = true;
      script.crossOrigin = 'anonymous';
      script.onerror = () => {
        console.warn('AdSense script failed to load. Ad-blocker might be active.');
        setAdBlockedOrFailed(true);
      };
      document.head.appendChild(script);
    }

    // Push ad unit
    try {
      const adsbygoogle = (window as any).adsbygoogle || [];
      adsbygoogle.push({});
      setAdLoaded(true);
    } catch (e) {
      console.error('AdSense ad placement error:', e);
      setAdBlockedOrFailed(true);
    }
  }, [client, slot, isDemoMode]);

  // Dimension styling based on adType
  const getAdDimensionsClass = () => {
    switch (adType) {
      case 'leaderboard':
        return 'w-full h-24 md:h-28 max-w-4xl mx-auto';
      case 'skyscraper':
        return 'w-full h-[600px] max-w-[160px] md:max-w-[300px]';
      case 'rectangle':
        return 'w-full max-w-[336px] h-[280px] mx-auto';
      case 'responsive':
      default:
        return 'w-full min-h-[100px]';
    }
  };

  // Mock Content for Demo Mode / AdBlock fallback
  const getMockAdContent = () => {
    const mockAds = [
      {
        title: 'أفضل حاسوب ألعاب لعام 2026!',
        badge: 'إعلان ممول',
        description: 'احصل على معالجات الجيل الجديد ومعدل إطارات خارق لتجربة ألعاب لا مثيل لها.',
        action: 'تسوّق الآن',
        bg: 'from-purple-900/60 to-slate-900',
        borderColor: 'border-purple-500/30',
        textColor: 'text-purple-300',
      },
      {
        title: 'تحدي أصدقائك في بطولة الألعاب الكبرى',
        badge: 'مسابقة',
        description: 'شارك نقاطك القياسية وسجل اسمك في لوحة الصدارة العالمية لتربح جوائز فورية.',
        action: 'اشترك مجاناً',
        bg: 'from-amber-950/50 to-slate-900',
        borderColor: 'border-amber-500/30',
        textColor: 'text-amber-300',
      },
      {
        title: 'تطبيق ألعاب السرعة والهواتف الذكية',
        badge: 'تطبيق مجاني',
        description: 'حمّل أحدث ألعاب الذكاء والأركيد مباشرة على هاتفك وعزّز مهاراتك اليومية.',
        action: 'تنزيل الآن',
        bg: 'from-cyan-950/50 to-slate-900',
        borderColor: 'border-cyan-500/30',
        textColor: 'text-cyan-300',
      },
    ];

    // Select based on slot string length or simple hash
    const index = (slot ? slot.length : 0) % mockAds.length;
    return mockAds[index];
  };

  const mockAd = getMockAdContent();

  // If in Demo Mode or if real ad script fails, render high fidelity mock ads
  if (isDemoMode || adBlockedOrFailed || !client || !slot) {
    return (
      <div
        className={`relative flex flex-col justify-between overflow-hidden rounded-xl border p-4 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 bg-gradient-to-br ${mockAd.bg} ${mockAd.borderColor}`}
        style={{ minHeight: adType === 'leaderboard' ? '90px' : adType === 'skyscraper' ? '400px' : '250px' }}
      >
        {/* Ad Tag Badge */}
        <div className="absolute top-2 left-2 flex items-center gap-1 text-[10px] font-medium tracking-wide text-gray-400 bg-black/40 backdrop-blur-md px-2 py-0.5 rounded-full">
          <span>{mockAd.badge}</span>
          <Info className="w-3 h-3 text-gray-500 cursor-help" title="هذا الإعلان هو محاكاة للعرض والتحضير لـ Google AdSense" />
        </div>

        {/* Ad Info in Footer or Header */}
        <div className="absolute top-2 right-2 flex items-center gap-1.5 text-[10px] text-gray-400">
          {(!client || !slot) && (
            <span className="bg-yellow-500/10 text-yellow-500 px-1.5 py-0.5 rounded text-[9px] border border-yellow-500/20">
              في انتظار المعرفات
            </span>
          )}
          {adBlockedOrFailed && !isDemoMode && (
            <span className="bg-red-500/10 text-red-500 px-1.5 py-0.5 rounded text-[9px] border border-red-500/20 flex items-center gap-0.5">
              <Shield className="w-2.5 h-2.5" /> حظر الإعلانات نشط
            </span>
          )}
        </div>

        {adType === 'leaderboard' ? (
          // Horizontal Layout for Leaderboard
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 h-full pt-4">
            <div className="flex-1 min-w-0 pr-4">
              <h4 className="font-bold text-sm text-white truncate flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                {mockAd.title}
              </h4>
              <p className="text-xs text-gray-300 mt-1 line-clamp-1">{mockAd.description}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
              <span className="text-[10px] text-gray-400 hidden lg:inline-block">إشهار بواسطة Google Ads (محاكاة)</span>
              <button className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white text-black hover:bg-gray-100 transition-colors shadow-sm cursor-pointer">
                {mockAd.action}
              </button>
            </div>
          </div>
        ) : adType === 'skyscraper' ? (
          // Vertical Layout for Skyscraper
          <div className="flex flex-col h-full justify-between pt-6 text-center">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center mx-auto border border-white/5 shadow-inner">
                <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
              </div>
              <div className="space-y-2 px-1">
                <h4 className="font-bold text-base text-white leading-snug">{mockAd.title}</h4>
                <p className="text-xs text-gray-400 leading-relaxed line-clamp-5">{mockAd.description}</p>
              </div>
            </div>
            <div className="space-y-3 mt-auto pt-4">
              <button className="w-full py-2.5 text-xs font-semibold rounded-lg bg-white text-black hover:bg-gray-100 transition-colors shadow-md cursor-pointer">
                {mockAd.action}
              </button>
              <div className="text-[9px] text-gray-500">
                مساحة إعلانية Google AdSense جاهزة للبث المباشر
              </div>
            </div>
          </div>
        ) : (
          // Rectangle Layout
          <div className="flex flex-col h-full justify-between pt-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center border border-white/5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                </div>
                <h4 className="font-bold text-sm text-white">{mockAd.title}</h4>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed mt-2">{mockAd.description}</p>
            </div>
            <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
              <span className="text-[9px] text-gray-500">Google Adsense Simulator</span>
              <button className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-white text-black hover:bg-gray-100 transition-colors shadow">
                {mockAd.action}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Real Google Adsense Tag
  return (
    <div className={`overflow-hidden rounded-xl border border-gray-800 bg-black/20 flex flex-col justify-center items-center ${getAdDimensionsClass()}`}>
      <div className="w-full text-left px-3 py-1 text-[9px] text-gray-500 border-b border-gray-900 bg-gray-950/50 flex justify-between">
        <span>إعلان بواسطة Google</span>
        <span>ID: {slot}</span>
      </div>
      <div className="w-full p-2 flex justify-center items-center overflow-hidden">
        <ins
          className="adsbygoogle"
          style={{ display: 'block', width: '100%' }}
          data-ad-client={client}
          data-ad-slot={slot}
          data-ad-format={format}
          data-full-width-responsive={isResponsive ? 'true' : 'false'}
        ></ins>
      </div>
    </div>
  );
}
