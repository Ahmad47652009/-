import React, { useState, useEffect, useRef } from 'react';
import { Game } from '../types';
import { Play, RotateCcw, Trophy, Sparkles, Coins, Zap, Shield, HelpCircle, Activity, Award, CheckCircle2, XCircle } from 'lucide-react';

interface CustomGameCanvasProps {
  game: Game;
}

export default function CustomGameCanvas({ game }: CustomGameCanvasProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    return Number(localStorage.getItem(`custom_game_high_${game.id}`) || '0');
  });
  const [gameOver, setGameOver] = useState(false);

  // --- Hybrid Game States ---
  // Clicker State
  const [clickValue, setClickValue] = useState(1);
  const [autoRate, setAutoRate] = useState(0);
  const [upgrades, setUpgrades] = useState({
    auto: { count: 0, cost: 30, power: 1, name: 'مساعد تلقائي 🤖', desc: 'يجمع +١ نقطة تلقائياً كل ثانية' },
    power: { count: 0, cost: 70, power: 2, name: 'جرعة تضاعفية ⚡', desc: 'تزيد من قوة النقرة بمقدار +٢ نقطة' },
    mega: { count: 0, cost: 250, power: 10, name: 'مفاعل مفرط 🌀', desc: 'يجمع +١٠ نقاط تلقائياً كل ثانية' },
  });

  // Math Challenge State
  const [mathQuestion, setMathQuestion] = useState('');
  const [mathOptions, setMathOptions] = useState<number[]>([]);
  const [mathAnswer, setMathAnswer] = useState<number>(0);
  const [mathTimer, setMathTimer] = useState(100); // Percentage of progress bar
  const mathTimerRef = useRef<number | null>(null);

  // Whack-a-Mole State
  const [whackHoles, setWhackHoles] = useState<('empty' | 'mole' | 'bomb')[]>(Array(9).fill('empty'));
  const whackIntervalRef = useRef<number | null>(null);

  // --- Canvas references and game variables ---
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number | null>(null);
  const keys = useRef<{[key: string]: boolean}>({});

  // Physics & Game state Refs for Canvas loop
  const playerPos = useRef({ x: 200, y: 400, vx: 0, vy: 0, size: 25, color: '#6366f1' });
  const enemies = useRef<{ x: number, y: number, vx: number, vy: number, size: number, type: string, symbol?: string }[]>([]);
  const projectiles = useRef<{ x: number, y: number, vy: number, size: number }[]>([]);
  const stars = useRef<{ x: number, y: number, speed: number }[]>([]);
  const colorIndex = useRef<number>(0); // 0: Red, 1: Green, 2: Blue
  const COLORS_LIST = ['#ef4444', '#10b981', '#3b82f6']; // Red, Green, Blue

  // Brick Breaker specific states
  const breakerBall = useRef({ x: 200, y: 250, vx: 3, vy: -3, size: 8 });
  const breakerBricks = useRef<{ x: number, y: number, w: number, h: number, active: boolean, color: string }[]>([]);

  // Tower Stacker specific states
  const stackerBlocks = useRef<{ y: number, x: number, w: number, h: number }[]>([]);
  const stackerActive = useRef({ x: 0, w: 160, dir: 1, speed: 4 });

  // Sync highscore and reset when game changes
  useEffect(() => {
    const savedHighScore = Number(localStorage.getItem(`custom_game_high_${game.id}`) || '0');
    setHighScore(savedHighScore);
    setIsPlaying(false);
    setGameOver(false);
    setScore(0);
    cleanupAll();

    // Reset Clicker specific variables
    setClickValue(1);
    setAutoRate(0);
    setUpgrades({
      auto: { count: 0, cost: 30, power: 1, name: 'مساعد تلقائي 🤖', desc: 'يجمع +١ نقطة تلقائياً كل ثانية' },
      power: { count: 0, cost: 70, power: 2, name: 'جرعة تضاعفية ⚡', desc: 'تزيد من قوة النقرة بمقدار +٢ نقطة' },
      mega: { count: 0, cost: 250, power: 10, name: 'مفاعل مفرط 🌀', desc: 'يجمع +١٠ نقاط تلقائياً كل ثانية' },
    });
  }, [game.id]);

  // Clean up timers and loops
  const cleanupAll = () => {
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
      requestRef.current = null;
    }
    if (mathTimerRef.current) {
      clearInterval(mathTimerRef.current);
      mathTimerRef.current = null;
    }
    if (whackIntervalRef.current) {
      clearInterval(whackIntervalRef.current);
      whackIntervalRef.current = null;
    }
  };

  useEffect(() => {
    return () => cleanupAll();
  }, []);

  // Sync high scores
  const triggerHighScoreCheck = (currentScore: number) => {
    if (currentScore > highScore) {
      setHighScore(currentScore);
      localStorage.setItem(`custom_game_high_${game.id}`, String(currentScore));
    }
  };

  // --- GAME 1: CLICKER SYSTEM (React State Loop) ---
  useEffect(() => {
    if (game.gameType !== 'clicker' || !isPlaying || gameOver) return;

    const interval = setInterval(() => {
      setScore(s => {
        const added = autoRate;
        const newScore = s + added;
        triggerHighScoreCheck(newScore);
        return newScore;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying, gameOver, autoRate, game.gameType]);

  const handleClickerTap = () => {
    setScore(s => {
      const newScore = s + clickValue;
      triggerHighScoreCheck(newScore);
      return newScore;
    });
  };

  const buyClickerUpgrade = (key: 'auto' | 'power' | 'mega') => {
    const upgrade = upgrades[key];
    if (score >= upgrade.cost) {
      setScore(s => s - upgrade.cost);
      setUpgrades(prev => {
        const updated = { ...prev };
        updated[key].count += 1;
        updated[key].cost = Math.floor(updated[key].cost * 1.5);
        return updated;
      });

      if (key === 'power') {
        setClickValue(v => v + upgrade.power);
      } else {
        setAutoRate(r => r + upgrade.power);
      }
    }
  };

  // --- GAME 2: WHACK-A-MOLE SYSTEM (React State Loop) ---
  const startWhackLoop = () => {
    setWhackHoles(Array(9).fill('empty'));
    if (whackIntervalRef.current) clearInterval(whackIntervalRef.current);

    whackIntervalRef.current = window.setInterval(() => {
      setWhackHoles(() => {
        const nextGrid = Array(9).fill('empty');
        const activeCount = Math.floor(Math.random() * 2) + 1; // 1 or 2 active moles
        for (let i = 0; i < activeCount; i++) {
          const randomIndex = Math.floor(Math.random() * 9);
          // 85% normal mole, 15% bomb
          nextGrid[randomIndex] = Math.random() < 0.18 ? 'bomb' : 'mole';
        }
        return nextGrid;
      });
    }, 900); // Speed changes based on difficulty or is static
  };

  const handleWhackHole = (index: number) => {
    const current = whackHoles[index];
    if (current === 'mole') {
      // Correct Whack!
      setScore(s => {
        const next = s + 20;
        triggerHighScoreCheck(next);
        return next;
      });
      setWhackHoles(prev => {
        const next = [...prev];
        next[index] = 'empty';
        return next;
      });
    } else if (current === 'bomb') {
      // Hit a bomb! Game over.
      setGameOver(true);
      setIsPlaying(false);
      cleanupAll();
    }
  };

  // --- GAME 3: MATH SPEED CHALLENGE (React State Loop) ---
  const generateMathQuestion = () => {
    // Math logic based on difficulty
    const operators = ['+', '-', '*'];
    let op = operators[Math.floor(Math.random() * operators.length)];
    if (game.difficulty === 'سهل' || game.difficulty === 'Easy') op = '+';
    
    let num1 = Math.floor(Math.random() * 12) + 1;
    let num2 = Math.floor(Math.random() * 12) + 1;

    // Keep operations simple
    if (op === '*') {
      num1 = Math.floor(Math.random() * 9) + 1;
      num2 = Math.floor(Math.random() * 9) + 1;
    } else if (op === '-') {
      if (num1 < num2) {
        const temp = num1;
        num1 = num2;
        num2 = temp;
      }
    }

    const questionStr = `${num1} ${op === '*' ? '×' : op} ${num2} = ?`;
    const ans = op === '+' ? num1 + num2 : op === '-' ? num1 - num2 : num1 * num2;

    // Options generator
    const wrong1 = ans + (Math.floor(Math.random() * 4) + 1) * (Math.random() < 0.5 ? 1 : -1);
    const wrong2 = ans + (Math.floor(Math.random() * 5) + 5) * (Math.random() < 0.5 ? 1 : -1);
    const uniqueOptions = Array.from(new Set([ans, wrong1, wrong2])).slice(0, 3);
    
    while (uniqueOptions.length < 3) {
      uniqueOptions.push(ans + uniqueOptions.length + 2);
    }
    
    // Shuffle options
    uniqueOptions.sort(() => Math.random() - 0.5);

    setMathQuestion(questionStr);
    setMathOptions(uniqueOptions);
    setMathAnswer(ans);
    setMathTimer(100);

    // Speed up timer marginally as score rises
    if (mathTimerRef.current) clearInterval(mathTimerRef.current);
    const duration = Math.max(1000, 4000 - score * 30); // starts at 4s, decreases
    const tickRate = 50; // ms
    const step = (tickRate / duration) * 100;

    mathTimerRef.current = window.setInterval(() => {
      setMathTimer(prev => {
        if (prev <= 0) {
          // Timeout Game Over
          setGameOver(true);
          setIsPlaying(false);
          cleanupAll();
          return 0;
        }
        return prev - step;
      });
    }, tickRate);
  };

  const handleMathAnswer = (option: number) => {
    if (option === mathAnswer) {
      // Correct!
      setScore(s => {
        const next = s + 15;
        triggerHighScoreCheck(next);
        return next;
      });
      generateMathQuestion();
    } else {
      // Wrong! Game Over
      setGameOver(true);
      setIsPlaying(false);
      cleanupAll();
    }
  };

  // --- GLOBAL START GAME ---
  const handleStartGame = () => {
    setIsPlaying(true);
    setGameOver(false);
    setScore(0);
    cleanupAll();

    // Reset general values
    keys.current = {};
    playerPos.current = { x: 200, y: 410, vx: 0, vy: 0, size: 25, color: '#6366f1' };
    enemies.current = [];
    projectiles.current = [];
    colorIndex.current = 0;

    // Star backdrop initialization
    stars.current = [];
    for (let i = 0; i < 20; i++) {
      stars.current.push({ x: Math.random() * 400, y: Math.random() * 500, speed: 1 + Math.random() * 2 });
    }

    // Brick Breaker reset
    if (game.gameType === 'breaker') {
      breakerBall.current = { x: 200, y: 280, vx: 2, vy: -3, size: 8 };
      breakerBricks.current = [];
      const colors = ['#f43f5e', '#ec4899', '#a855f7', '#6366f1', '#14b8a6'];
      for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 5; c++) {
          breakerBricks.current.push({
            x: 10 + c * 76,
            y: 50 + r * 22,
            w: 68,
            h: 15,
            active: true,
            color: colors[r % colors.length]
          });
        }
      }
    }

    // Tower Stacker reset
    if (game.gameType === 'stacker') {
      stackerBlocks.current = [{ y: 460, x: 120, w: 160, h: 25 }];
      stackerActive.current = { x: 0, w: 160, dir: 1, speed: 4 };
    }

    // Start-up triggers for unique React games
    if (game.gameType === 'math') {
      generateMathQuestion();
    } else if (game.gameType === 'whack') {
      startWhackLoop();
    }
  };

  // --- CANVAS GAME ENGINES (Unified Loop) ---
  useEffect(() => {
    const isCanvasGame = ['dodge', 'flappy', 'shooter', 'catcher', 'breaker', 'stacker', 'color'].includes(game.gameType || '');
    if (!isPlaying || gameOver || !isCanvasGame) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 400;
    canvas.height = 500;

    // Listeners for left, right, and space
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'a', 'd', 's', 'w', ' '].includes(e.key)) {
        keys.current[e.key] = true;
        // Space/Up triggers jump in flappy and shooting in shooter
        if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') {
          handleActionTrigger();
        }
        e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'a', 'd', 's', 'w', ' '].includes(e.key)) {
        keys.current[e.key] = false;
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Space/Tap Action Router
    const handleActionTrigger = () => {
      if (game.gameType === 'flappy') {
        playerPos.current.vy = -5.5; // Jump
      } else if (game.gameType === 'shooter') {
        // Spawn projectile from player ship
        projectiles.current.push({
          x: playerPos.current.x,
          y: playerPos.current.y - 15,
          vy: -7,
          size: 4
        });
      } else if (game.gameType === 'color') {
        // Swap color index
        colorIndex.current = (colorIndex.current + 1) % 3;
      } else if (game.gameType === 'stacker') {
        executeStackerDrop();
      }
    };

    const executeStackerDrop = () => {
      const active = stackerActive.current;
      const blocks = stackerBlocks.current;
      const targetBlock = blocks[blocks.length - 1];

      // Left boundaries of stack alignment
      const leftBound = Math.max(active.x, targetBlock.x);
      const rightBound = Math.min(active.x + active.w, targetBlock.x + targetBlock.w);
      const overlapWidth = rightBound - leftBound;

      if (overlapWidth <= 0) {
        // Missed completely! Game Over
        setGameOver(true);
        setIsPlaying(false);
      } else {
        // Successful stack!
        const nextY = targetBlock.y - 25;
        blocks.push({
          y: nextY,
          x: leftBound,
          w: overlapWidth,
          h: 25
        });

        // Add Score!
        setScore(s => {
          const next = s + 10;
          triggerHighScoreCheck(next);
          return next;
        });

        // Move stack down visualizer if too high
        if (nextY < 150) {
          blocks.forEach(b => b.y += 25);
        }

        // Prep next level
        stackerActive.current = {
          x: 0,
          w: overlapWidth,
          dir: Math.random() < 0.5 ? 1 : -1,
          speed: Math.min(10, 4 + blocks.length * 0.15) // Speed rises
        };
      }
    };

    // Main Game Cycle
    let frameCount = 0;
    const loop = () => {
      frameCount++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Render Dynamic Backdrop
      ctx.fillStyle = '#0a0d1a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars floating
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      stars.current.forEach(star => {
        star.y += star.speed;
        if (star.y > canvas.height) star.y = 0;
        ctx.fillRect(star.x, star.y, 2, 2);
      });

      // --- ENGINE 1: DODGE GAMEPLAY ---
      if (game.gameType === 'dodge') {
        // Movement
        if (keys.current['ArrowLeft'] || keys.current['a']) playerPos.current.x = Math.max(20, playerPos.current.x - 5);
        if (keys.current['ArrowRight'] || keys.current['d']) playerPos.current.x = Math.min(canvas.width - 20, playerPos.current.x + 5);

        // Draw Player Ship
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(game.icon, playerPos.current.x, playerPos.current.y);

        // Spawn falling debris / particles
        if (Math.random() < 0.03 + score * 0.0005) {
          enemies.current.push({
            x: Math.random() * (canvas.width - 40) + 20,
            y: -20,
            vx: 0,
            vy: 2.5 + Math.random() * 3 + score * 0.005,
            size: 15 + Math.random() * 15,
            type: 'obstacle'
          });
        }
        if (Math.random() < 0.02) {
          enemies.current.push({
            x: Math.random() * (canvas.width - 40) + 20,
            y: -20,
            vx: 0,
            vy: 2 + Math.random() * 2,
            size: 12,
            type: 'gold'
          });
        }

        // Draw and collision
        enemies.current.forEach((enemy, index) => {
          enemy.y += enemy.vy;

          if (enemy.type === 'obstacle') {
            // Draw red obstacle asteroid
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#f43f5e';
            ctx.fillStyle = '#f43f5e';
            ctx.beginPath();
            ctx.arc(enemy.x, enemy.y, enemy.size / 2, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;

            // Collision
            const dist = Math.hypot(enemy.x - playerPos.current.x, enemy.y - playerPos.current.y);
            if (dist < (enemy.size / 2 + 12)) {
              setGameOver(true);
              setIsPlaying(false);
            }
          } else {
            // Draw gold star
            ctx.shadowBlur = 12;
            ctx.shadowColor = '#eab308';
            ctx.font = '16px sans-serif';
            ctx.fillText('⭐', enemy.x, enemy.y);
            ctx.shadowBlur = 0;

            // Collide
            const dist = Math.hypot(enemy.x - playerPos.current.x, enemy.y - playerPos.current.y);
            if (dist < (enemy.size / 2 + 14)) {
              setScore(s => {
                const next = s + 15;
                triggerHighScoreCheck(next);
                return next;
              });
              enemies.current.splice(index, 1);
            }
          }
        });
      }

      // --- ENGINE 2: FLAPPY JUMPER ---
      else if (game.gameType === 'flappy') {
        // Player gravity
        playerPos.current.vy += 0.22; // gravity force
        playerPos.current.y += playerPos.current.vy;

        // Visuals
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(game.icon, 80, playerPos.current.y);

        // Ground / Ceiling crash
        if (playerPos.current.y > canvas.height + 20 || playerPos.current.y < -20) {
          setGameOver(true);
          setIsPlaying(false);
        }

        // Spawn Pipes
        if (frameCount % 100 === 0) {
          const gapHeight = 110;
          const minH = 50;
          const maxH = canvas.height - gapHeight - minH;
          const topHeight = Math.floor(Math.random() * (maxH - minH)) + minH;

          enemies.current.push({
            x: canvas.width + 40,
            y: topHeight,
            vx: -3,
            vy: 0,
            size: gapHeight,
            type: 'pipe'
          });
        }

        // Draw and Collision
        enemies.current.forEach((pipe, idx) => {
          pipe.x += pipe.vx;

          // Draw neon columns
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#6366f1';
          ctx.fillStyle = '#6366f1';
          // Top Pillar
          ctx.fillRect(pipe.x - 20, 0, 40, pipe.y);
          // Bottom Pillar
          ctx.fillRect(pipe.x - 20, pipe.y + pipe.size, 40, canvas.height - (pipe.y + pipe.size));
          ctx.shadowBlur = 0;

          // Check passing score
          if (pipe.x + 3 === 80) {
            setScore(s => {
              const next = s + 10;
              triggerHighScoreCheck(next);
              return next;
            });
          }

          // AABB Collision with bird (centered X=80, Radius=12)
          const birdX = 80;
          const birdY = playerPos.current.y;
          if (birdX + 12 > pipe.x - 20 && birdX - 12 < pipe.x + 20) {
            if (birdY - 12 < pipe.y || birdY + 12 > pipe.y + pipe.size) {
              setGameOver(true);
              setIsPlaying(false);
            }
          }
        });
      }

      // --- ENGINE 3: SPACE SHOOTER ---
      else if (game.gameType === 'shooter') {
        // Move Left/Right
        if (keys.current['ArrowLeft'] || keys.current['a']) playerPos.current.x = Math.max(25, playerPos.current.x - 5);
        if (keys.current['ArrowRight'] || keys.current['d']) playerPos.current.x = Math.min(canvas.width - 25, playerPos.current.x + 5);

        // Draw Player Jet Fighter
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(game.icon, playerPos.current.x, playerPos.current.y);

        // Draw bullets
        ctx.fillStyle = '#10b981';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#10b981';
        projectiles.current.forEach((proj, pIdx) => {
          proj.y += proj.vy;
          ctx.beginPath();
          ctx.arc(proj.x, proj.y, proj.size, 0, Math.PI * 2);
          ctx.fill();

          // Offscreen clean
          if (proj.y < 0) projectiles.current.splice(pIdx, 1);
        });
        ctx.shadowBlur = 0;

        // Spawn Alien Enemies
        if (Math.random() < 0.035) {
          enemies.current.push({
            x: Math.random() * (canvas.width - 40) + 20,
            y: -20,
            vx: (Math.random() - 0.5) * 1.5,
            vy: 2 + Math.random() * 2,
            size: 20,
            type: 'alien',
            symbol: Math.random() < 0.5 ? '👾' : '🛸'
          });
        }

        // Render Aliens & handle Bullet impacts
        enemies.current.forEach((alien, aIdx) => {
          alien.x += alien.vx;
          alien.y += alien.vy;

          // Wall bounce
          if (alien.x < 15 || alien.x > canvas.width - 15) alien.vx *= -1;

          ctx.font = '22px sans-serif';
          ctx.fillText(alien.symbol || '👾', alien.x, alien.y);

          // Bullet Collision
          projectiles.current.forEach((bullet, bIdx) => {
            const dist = Math.hypot(bullet.x - alien.x, bullet.y - alien.y);
            if (dist < 18) {
              // Destroy!
              setScore(s => {
                const next = s + 15;
                triggerHighScoreCheck(next);
                return next;
              });
              enemies.current.splice(aIdx, 1);
              projectiles.current.splice(bIdx, 1);
            }
          });

          // Player collision or bottom collision
          const crashDist = Math.hypot(alien.x - playerPos.current.x, alien.y - playerPos.current.y);
          if (crashDist < 25 || alien.y > canvas.height + 20) {
            setGameOver(true);
            setIsPlaying(false);
          }
        });
      }

      // --- ENGINE 4: FRUIT/GEM CATCHER ---
      else if (game.gameType === 'catcher') {
        // Move Basket
        if (keys.current['ArrowLeft'] || keys.current['a']) playerPos.current.x = Math.max(40, playerPos.current.x - 6);
        if (keys.current['ArrowRight'] || keys.current['d']) playerPos.current.x = Math.min(canvas.width - 40, playerPos.current.x + 6);

        // Draw Player Basket bowl
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(playerPos.current.x, playerPos.current.y + 10, 30, 0, Math.PI, false);
        ctx.closePath();
        ctx.fill();
        ctx.font = '22px sans-serif';
        ctx.fillText('🧺', playerPos.current.x, playerPos.current.y - 10);

        // Spawns
        if (Math.random() < 0.04) {
          const isBomb = Math.random() < 0.22;
          enemies.current.push({
            x: Math.random() * (canvas.width - 40) + 20,
            y: -20,
            vx: 0,
            vy: 2.5 + Math.random() * 2.5 + score * 0.005,
            size: 16,
            type: isBomb ? 'bomb' : 'fruit',
            symbol: isBomb ? '💣' : ['🍎', '🍉', '🍇', '🍒', '🍓', '💎'][Math.floor(Math.random() * 6)]
          });
        }

        // Render and Collection
        enemies.current.forEach((item, idx) => {
          item.y += item.vy;
          ctx.font = '22px sans-serif';
          ctx.fillText(item.symbol || '🍎', item.x, item.y);

          // Catch check
          const distY = Math.abs(item.y - playerPos.current.y);
          const distX = Math.abs(item.x - playerPos.current.x);
          if (distY < 15 && distX < 30) {
            if (item.type === 'bomb') {
              // Bang! Game over
              setGameOver(true);
              setIsPlaying(false);
            } else {
              setScore(s => {
                const next = s + 10;
                triggerHighScoreCheck(next);
                return next;
              });
              enemies.current.splice(idx, 1);
            }
          }

          // missed clean up
          if (item.y > canvas.height + 20) {
            enemies.current.splice(idx, 1);
          }
        });
      }

      // --- ENGINE 5: BRICK BREAKER ---
      else if (game.gameType === 'breaker') {
        // Paddle movement
        if (keys.current['ArrowLeft'] || keys.current['a']) playerPos.current.x = Math.max(45, playerPos.current.x - 6);
        if (keys.current['ArrowRight'] || keys.current['d']) playerPos.current.x = Math.min(canvas.width - 45, playerPos.current.x + 6);

        // Draw paddle
        ctx.fillStyle = '#6366f1';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#6366f1';
        ctx.fillRect(playerPos.current.x - 45, playerPos.current.y, 90, 12);
        ctx.shadowBlur = 0;

        // Ball math
        const ball = breakerBall.current;
        ball.x += ball.vx;
        ball.y += ball.vy;

        // Draw ball
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.size, 0, Math.PI * 2);
        ctx.fill();

        // Bounce borders
        if (ball.x < ball.size || ball.x > canvas.width - ball.size) ball.vx *= -1;
        if (ball.y < ball.size) ball.vy *= -1;

        // Paddle bounce
        if (ball.y + ball.size >= playerPos.current.y && ball.y - ball.size <= playerPos.current.y + 12) {
          if (ball.x >= playerPos.current.x - 45 && ball.x <= playerPos.current.x + 45) {
            ball.vy = -Math.abs(ball.vy); // Bounce up
            // Alter bounce angle slightly based on hit location
            const offset = (ball.x - playerPos.current.x) / 45;
            ball.vx = offset * 4;
          }
        }

        // Check crash bottom
        if (ball.y > canvas.height + 20) {
          setGameOver(true);
          setIsPlaying(false);
        }

        // Render and destroy bricks
        let activeBricks = 0;
        breakerBricks.current.forEach(brick => {
          if (!brick.active) return;
          activeBricks++;

          ctx.fillStyle = brick.color;
          ctx.fillRect(brick.x, brick.y, brick.w, brick.h);

          // Ball/Brick overlap
          if (ball.x + ball.size > brick.x && ball.x - ball.size < brick.x + brick.w) {
            if (ball.y + ball.size > brick.y && ball.y - ball.size < brick.y + brick.h) {
              brick.active = false;
              ball.vy *= -1; // Bounce back
              setScore(s => {
                const next = s + 20;
                triggerHighScoreCheck(next);
                return next;
              });
            }
          }
        });

        // Spawn new brick grid if all crushed
        if (activeBricks === 0) {
          breakerBricks.current.forEach(b => b.active = true);
          ball.vy = -Math.abs(ball.vy) * 1.05; // boost speed slightly
        }
      }

      // --- ENGINE 6: TOWER STACKER ---
      else if (game.gameType === 'stacker') {
        const blocks = stackerBlocks.current;
        const active = stackerActive.current;

        // Slide active block left/right
        active.x += active.speed * active.dir;
        if (active.x <= 0) {
          active.x = 0;
          active.dir = 1;
        } else if (active.x + active.w >= canvas.width) {
          active.x = canvas.width - active.w;
          active.dir = -1;
        }

        // Draw stacked tower
        blocks.forEach((block, index) => {
          ctx.fillStyle = `hsl(${180 + index * 10}, 80%, 55%)`;
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 1.5;
          ctx.fillRect(block.x, block.y, block.w, block.h);
          ctx.strokeRect(block.x, block.y, block.w, block.h);
        });

        // Draw sliding active block
        const activeY = blocks[blocks.length - 1].y - 25;
        ctx.fillStyle = '#fbbf24';
        ctx.strokeStyle = '#ffffff';
        ctx.fillRect(active.x, activeY, active.w, 25);
        ctx.strokeRect(active.x, activeY, active.w, 25);
      }

      // --- ENGINE 7: COLOR SWAPPER ---
      else if (game.gameType === 'color') {
        // Render central player color ring
        const currentHexColor = COLORS_LIST[colorIndex.current];
        ctx.strokeStyle = currentHexColor;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(200, 380, 22, 0, Math.PI * 2);
        ctx.stroke();
        
        ctx.fillStyle = currentHexColor;
        ctx.beginPath();
        ctx.arc(200, 380, 10, 0, Math.PI * 2);
        ctx.fill();

        // Spawn color nodes
        if (Math.random() < 0.025) {
          const randColIdx = Math.floor(Math.random() * 3);
          enemies.current.push({
            x: 200,
            y: -20,
            vx: 0,
            vy: 3 + score * 0.005,
            size: 16,
            type: String(randColIdx) // Store color index as string
          });
        }

        // Update color nodes
        enemies.current.forEach((node, idx) => {
          node.y += node.vy;

          const nodeColorHex = COLORS_LIST[Number(node.type)];
          ctx.shadowBlur = 10;
          ctx.shadowColor = nodeColorHex;
          ctx.fillStyle = nodeColorHex;
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          // Check hit
          const dist = Math.abs(node.y - 380);
          if (dist < 22) {
            // Hit!
            if (Number(node.type) === colorIndex.current) {
              // Match!
              setScore(s => {
                const next = s + 15;
                triggerHighScoreCheck(next);
                return next;
              });
              enemies.current.splice(idx, 1);
            } else {
              // Boom! Wrong color collision
              setGameOver(true);
              setIsPlaying(false);
            }
          }

          // Offscreen safe cleaning
          if (node.y > canvas.height + 20) {
            enemies.current.splice(idx, 1);
          }
        });
      }

      // Loop triggers
      enemies.current = enemies.current.filter(e => e.x > -50 && e.x < canvas.width + 50 && e.y < canvas.height + 50);

      if (!gameOver) {
        requestRef.current = requestAnimationFrame(loop);
      }
    };

    requestRef.current = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isPlaying, gameOver, game.id, score, highScore]);

  return (
    <div className="flex flex-col items-center gap-6 text-right" id="custom-game-embedded-runner" dir="rtl">
      
      {/* Upper Unified Dashboard Status block */}
      <div className="w-full bg-slate-950/60 p-4 rounded-3xl border border-slate-800 flex items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
          <span>تصنيف اللعبة: <strong className="text-indigo-400">{game.categoryAr}</strong></span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="hidden sm:inline">المصمم: <strong className="text-slate-200">{game.authorName}</strong></span>
        </div>
        <div className="flex items-center gap-1.5 text-yellow-400 font-bold">
          <Trophy className="w-3.5 h-3.5" />
          <span>الرقم القياسي: <strong className="font-mono">{highScore}</strong></span>
        </div>
      </div>

      {/* Main Screen Console */}
      <div className="relative w-full max-w-[400px] aspect-[4/5] bg-slate-950 rounded-3xl overflow-hidden border-4 border-indigo-500/20 shadow-2xl flex flex-col justify-center items-center">
        
        {/* Playback Switcher */}
        {isPlaying ? (
          
          // Render Canvas-based game types
          ['dodge', 'flappy', 'shooter', 'catcher', 'breaker', 'stacker', 'color'].includes(game.gameType || '') ? (
            <canvas ref={canvasRef} className="w-full h-full block cursor-pointer" onClick={() => {
              // Fast tap action router
              if (game.gameType === 'flappy') playerPos.current.vy = -5.5;
              else if (game.gameType === 'color') colorIndex.current = (colorIndex.current + 1) % 3;
              else if (game.gameType === 'stacker') {
                const canvas = canvasRef.current;
                if (canvas) {
                  const event = new KeyboardEvent('keydown', { key: ' ' });
                  window.dispatchEvent(event);
                }
              }
            }} />
          ) : 
          
          // Render Clicker Tycoon game type
          game.gameType === 'clicker' ? (
            <div className="absolute inset-0 bg-gradient-to-b from-slate-950 to-indigo-950/40 p-5 flex flex-col justify-between items-center text-center">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-black">الرصيد الكلي</span>
                <div className="text-3xl font-black text-indigo-400 font-mono flex items-center gap-1 justify-center">
                  <Coins className="w-6 h-6 text-yellow-400" />
                  <span>{score.toLocaleString('ar-EG')}</span>
                </div>
                <p className="text-[10px] text-emerald-400 font-bold">معدل التوليد: +{autoRate}/ثانية</p>
              </div>

              {/* Click button */}
              <button
                onClick={handleClickerTap}
                className="w-28 h-28 rounded-full bg-indigo-600/20 border-4 border-indigo-500 hover:border-indigo-400 text-6xl shadow-xl shadow-indigo-500/10 flex items-center justify-center cursor-pointer transition-all active:scale-90 select-none animate-pulse hover:animate-none"
              >
                {game.icon}
              </button>

              {/* Clicker upgrade grid */}
              <div className="w-full space-y-2">
                <span className="text-[9px] text-slate-500 font-bold text-right block pr-1">الترقيات والآلات:</span>
                <div className="grid grid-cols-1 gap-1.5 max-h-[140px] overflow-y-auto pr-1 no-scrollbar text-right">
                  {(Object.keys(upgrades) as ('auto' | 'power' | 'mega')[]).map(key => {
                    const item = upgrades[key];
                    const canAfford = score >= item.cost;
                    return (
                      <button
                        key={key}
                        onClick={() => buyClickerUpgrade(key)}
                        disabled={!canAfford}
                        className={`flex items-center justify-between p-2 rounded-xl border text-xs transition-all ${
                          canAfford 
                            ? 'bg-slate-900 hover:bg-indigo-950/20 border-slate-800 hover:border-indigo-500 cursor-pointer' 
                            : 'bg-slate-900/40 border-slate-900/60 opacity-60 cursor-not-allowed'
                        }`}
                      >
                        <div className="text-right">
                          <div className="font-bold text-white flex items-center gap-1">
                            <span>{item.name}</span>
                            <span className="text-[9px] font-mono bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded">x{item.count}</span>
                          </div>
                          <span className="text-[9px] text-slate-400">{item.desc}</span>
                        </div>
                        <div className="bg-yellow-500/10 text-yellow-500 font-bold px-2 py-1 rounded-lg text-[10px] font-mono">
                          {item.cost} 🪙
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ) :

          // Render Whack-a-Mole game type
          game.gameType === 'whack' ? (
            <div className="absolute inset-0 bg-slate-950 p-6 flex flex-col justify-between items-center">
              <div className="text-center">
                <span className="text-slate-500 text-[10px] font-bold block uppercase tracking-widest">مطرقة السرعة</span>
                <h4 className="text-xl font-black text-indigo-400 font-mono">{score} نقطة</h4>
              </div>

              {/* 3x3 Grid holes */}
              <div className="grid grid-cols-3 gap-3 w-full max-w-[280px]">
                {whackHoles.map((hole, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleWhackHole(idx)}
                    className="aspect-square rounded-2xl bg-slate-900 border-2 border-slate-850 flex items-center justify-center text-3xl cursor-pointer relative overflow-hidden active:bg-slate-800 transition-all shadow-inner"
                  >
                    {/* Mole hole bottom */}
                    <div className="absolute bottom-0 w-full h-1/4 bg-slate-950/80 rounded-t-full"></div>
                    
                    {/* Active target */}
                    {hole === 'mole' && (
                      <div className="animate-bounce text-4xl transform -translate-y-1 select-none pointer-events-none">
                        {game.icon}
                      </div>
                    )}
                    {hole === 'bomb' && (
                      <div className="animate-ping text-3xl select-none pointer-events-none">
                        💣
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="text-center text-[10px] text-slate-500">
                اضرب الـ {game.icon} بسرعة بمجرد ظهورها، وتجنب لمس القنابل 💣 المتفجرة!
              </div>
            </div>
          ) :

          // Render Math speed challenge game type
          game.gameType === 'math' ? (
            <div className="absolute inset-0 bg-slate-950 p-6 flex flex-col justify-between items-center">
              <div className="w-full flex justify-between items-center border-b border-slate-900 pb-3">
                <div>
                  <span className="text-[10px] text-slate-500 font-bold block">النقاط الإجمالية</span>
                  <strong className="text-base text-emerald-400 font-mono">{score}</strong>
                </div>
                <div className="text-left">
                  <span className="text-[10px] text-slate-500 font-bold block">أكاديمية العباقرة</span>
                  <span className="text-xs text-slate-300 font-bold">تحدي الحساب</span>
                </div>
              </div>

              {/* Timer line indicator */}
              <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-500 h-full transition-all duration-75"
                  style={{ width: `${mathTimer}%` }}
                ></div>
              </div>

              {/* Big Equation card */}
              <div className="bg-slate-900 border border-slate-850 py-8 px-6 rounded-3xl w-full text-center shadow-lg my-2">
                <HelpCircle className="w-8 h-8 text-indigo-400 mx-auto mb-2 animate-bounce" />
                <div className="text-3xl font-black text-white tracking-wide font-mono select-none" dir="ltr">
                  {mathQuestion}
                </div>
              </div>

              {/* 3 options clickable buttons */}
              <div className="w-full space-y-2.5">
                {mathOptions.map((opt, oIdx) => (
                  <button
                    key={oIdx}
                    onClick={() => handleMathAnswer(opt)}
                    className="w-full py-3.5 bg-slate-900 hover:bg-indigo-600 border border-slate-850 hover:border-indigo-400 rounded-2xl text-xs font-black text-slate-300 hover:text-white transition-all active:scale-[0.98] cursor-pointer"
                  >
                    {opt.toLocaleString('ar-EG')}
                  </button>
                ))}
              </div>
            </div>
          ) : null

        ) : (
          
          // START LOBBY / PREGAME VIEW
          <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-4xl shadow-lg shadow-indigo-500/20 animate-bounce">
              {game.icon}
            </div>
            
            <div className="space-y-2">
              <h4 className="text-xl font-black text-white flex items-center gap-1.5 justify-center">
                <span>{game.titleAr}</span>
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed max-w-xs">{game.descAr}</p>
            </div>

            {/* Specialized Gameplay description panel */}
            <div className="bg-slate-900/60 border border-slate-850 p-4 rounded-2xl w-full text-xs text-slate-400 space-y-1.5 text-right">
              <div className="font-bold text-indigo-400 flex items-center gap-1.5 justify-end">
                <span>أسلوب وطريقة اللعب:</span>
                <Activity className="w-3.5 h-3.5" />
              </div>
              
              {game.gameType === 'dodge' && (
                <div>استخدم أزرار الأسهم يميناً ويساراً (أو الأزرار اللمسية بالأسفل) لتفادي الكتل الحمراء المتساقطة وجمع النجوم ⭐ الذهبية لجمع نقاط لا متناهية!</div>
              )}
              {game.gameType === 'flappy' && (
                <div>اضغط على زر (القفز ⬆️) أو زر المسافة في الكيبورد لتطير للأعلى، وتجنب الارتطام بالأعمدة المجرية المضيئة!</div>
              )}
              {game.gameType === 'shooter' && (
                <div>تحرك يميناً ويساراً وأطلق النار بسرعة بالضغط على (إطلاق 🎯) أو زر المسافة لتفجير الغزاة الفضائيين 👾 قبل فوات الأوان!</div>
              )}
              {game.gameType === 'catcher' && (
                <div>حرك السلة لتلتقط كل الثمار والفاكهة اللذيذة المتساقطة من السماء لتكسب نقاطاً، واحذر تماماً من التقاط القنابل 💣!</div>
              )}
              {game.gameType === 'clicker' && (
                <div>لعبة نقر واستراتيجية! انقر فوق البسكوتة أو المجسم العملاق لتوليد نقاط، وقم بشراء المساعدين لتكسب ملايين الأرباح تلقائياً!</div>
              )}
              {game.gameType === 'breaker' && (
                <div>تحكم في المضرب الملون وارتد بالكرة للأعلى لتحطيم صفوف جدار الطوب بالكامل! لا تدع الكرة تسقط للأسفل لتفادي الخسارة.</div>
              )}
              {game.gameType === 'stacker' && (
                <div>تحدي توازن دقيق! انقر (رص / إسقاط) لوضع قوالب البناء المنزلقة فوق بعضها بدقة لبناء أطول ناطحة سحاب عملاقة.</div>
              )}
              {game.gameType === 'whack' && (
                <div>اضرب الكائنات المزعجة {game.icon} فور ظهورها من الثقوب بلمسة سريعة، واحذر بشدة من قرقعة القنابل الحمراء المتفجرة!</div>
              )}
              {game.gameType === 'math' && (
                <div>تحدي العباقرة الحسابي السريع! اختر الإجابة الحسابية الصحيحة للمعادلة المعروضة قبل نفاد شريط الوقت الضيق!</div>
              )}
              {game.gameType === 'color' && (
                <div>اضغط لتغيير لون الكبسولة الدائرية الخاص بك (أحمر، أخضر، أزرق)، ليمتص قطرات الطاقة الملونة المطابقة للونه بالكامل.</div>
              )}
            </div>

            {gameOver && (
              <div className="bg-red-500/10 border border-red-500/20 px-5 py-3 rounded-2xl text-xs text-red-400 font-bold flex items-center gap-2 justify-center">
                <XCircle className="w-4 h-4 text-red-400" />
                <span>انتهت اللعبة! مجموع نقاطك: <strong className="font-mono text-white text-sm bg-red-900/40 px-2 py-0.5 rounded">{score}</strong></span>
              </div>
            )}

            <button
              onClick={handleStartGame}
              className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 hover:scale-105 active:scale-95 text-white font-black text-sm rounded-xl transition-all shadow-lg shadow-indigo-500/20 flex items-center gap-2 cursor-pointer"
            >
              {gameOver ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{gameOver ? 'إعادة اللعب مجدداً' : 'ابدأ تشغيل اللعبة'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Tactile On-Screen Gamepad Controls (Customized by Game Type) */}
      {isPlaying && (
        <div className="w-full max-w-[340px]">
          
          {/* Controllers for Left/Right movement action games */}
          {['dodge', 'shooter', 'catcher', 'breaker'].includes(game.gameType || '') && (
            <div className="flex gap-4 items-center justify-between">
              <button
                onMouseDown={() => { keys.current['ArrowLeft'] = true; }}
                onMouseUp={() => { keys.current['ArrowLeft'] = false; }}
                onTouchStart={(e) => { e.preventDefault(); keys.current['ArrowLeft'] = true; }}
                onTouchEnd={(e) => { e.preventDefault(); keys.current['ArrowLeft'] = false; }}
                className="flex-1 py-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-2xl rounded-2xl font-black text-slate-300 active:bg-indigo-600 select-none cursor-pointer"
              >
                ◀
              </button>
              
              <div className="flex flex-col justify-center items-center px-4 bg-slate-950/40 border border-slate-900 rounded-xl min-w-[90px] h-14">
                <span className="text-[9px] text-slate-500 font-bold">النقاط</span>
                <span className="font-mono text-base font-black text-indigo-400">{score}</span>
              </div>

              {game.gameType === 'shooter' && (
                <button
                  onClick={() => {
                    projectiles.current.push({
                      x: playerPos.current.x,
                      y: playerPos.current.y - 15,
                      vy: -7,
                      size: 4
                    });
                  }}
                  className="px-5 py-4 bg-emerald-600 hover:bg-emerald-500 text-xs font-black text-white rounded-2xl active:scale-95 cursor-pointer select-none"
                >
                  إطلاق 🎯
                </button>
              )}

              <button
                onMouseDown={() => { keys.current['ArrowRight'] = true; }}
                onMouseUp={() => { keys.current['ArrowRight'] = false; }}
                onTouchStart={(e) => { e.preventDefault(); keys.current['ArrowRight'] = true; }}
                onTouchEnd={(e) => { e.preventDefault(); keys.current['ArrowRight'] = false; }}
                className="flex-1 py-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-2xl rounded-2xl font-black text-slate-300 active:bg-indigo-600 select-none cursor-pointer"
              >
                ▶
              </button>
            </div>
          )}

          {/* Controller for gravity flappy leap */}
          {game.gameType === 'flappy' && (
            <div className="flex gap-4 items-center justify-between">
              <div className="flex-1 bg-slate-950/40 border border-slate-900 rounded-2xl px-4 py-3 text-right">
                <span className="text-[9px] text-slate-500 font-bold block">النقاط المجمعة</span>
                <span className="font-mono text-base font-black text-indigo-400">{score}</span>
              </div>
              <button
                onClick={() => { playerPos.current.vy = -5.5; }}
                className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm rounded-2xl active:scale-95 select-none cursor-pointer shadow-lg shadow-indigo-500/15"
              >
                قفز للأعلى ⬆️
              </button>
            </div>
          )}

          {/* Controller for Tower Stacker */}
          {game.gameType === 'stacker' && (
            <div className="flex gap-4 items-center justify-between">
              <div className="flex-1 bg-slate-950/40 border border-slate-900 rounded-2xl px-4 py-3 text-right">
                <span className="text-[9px] text-slate-500 font-bold block">ارتفاع الطوابق</span>
                <span className="font-mono text-base font-black text-indigo-400">{score / 10} طابق</span>
              </div>
              <button
                onClick={() => {
                  const event = new KeyboardEvent('keydown', { key: ' ' });
                  window.dispatchEvent(event);
                }}
                className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm rounded-2xl active:scale-95 select-none cursor-pointer shadow-lg shadow-indigo-500/15"
              >
                إسقاط ورص القالب 🧱
              </button>
            </div>
          )}

          {/* Controller for Color Swapper */}
          {game.gameType === 'color' && (
            <div className="flex gap-4 items-center justify-between">
              <div className="flex-1 bg-slate-950/40 border border-slate-900 rounded-2xl px-4 py-3 text-right">
                <span className="text-[9px] text-slate-500 font-bold block">النقاط</span>
                <span className="font-mono text-base font-black text-indigo-400">{score}</span>
              </div>
              <button
                onClick={() => { colorIndex.current = (colorIndex.current + 1) % 3; }}
                className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm rounded-2xl active:scale-95 select-none cursor-pointer shadow-lg shadow-indigo-500/15"
              >
                تغيير لوني 🎨
              </button>
            </div>
          )}

          {/* Clicker back to lobby controller */}
          {['clicker', 'whack', 'math'].includes(game.gameType || '') && (
            <div className="flex justify-center">
              <button
                onClick={() => {
                  setGameOver(true);
                  setIsPlaying(false);
                  cleanupAll();
                }}
                className="px-6 py-2 bg-red-600/10 hover:bg-red-600 border border-red-500/20 hover:border-red-500 text-red-400 hover:text-white font-black text-[10px] rounded-full transition-all cursor-pointer"
              >
                إنهاء وتجاوز اللعبة 🛑
              </button>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
