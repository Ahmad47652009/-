import React from 'react';
import { AdConfig } from '../types';
import { Settings, HelpCircle, Save, ToggleLeft, ToggleRight, Info, Check, AlertCircle } from 'lucide-react';

interface AdSettingsProps {
  config: AdConfig;
  onUpdateConfig: (config: AdConfig) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function AdSettings({ config, onUpdateConfig, isOpen, onClose }: AdSettingsProps) {
  const [localConfig, setLocalConfig] = React.useState<AdConfig>({ ...config });
  const [isSaved, setIsSaved] = React.useState(false);

  React.useEffect(() => {
    setLocalConfig({ ...config });
  }, [config, isOpen]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateConfig(localConfig);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in" dir="rtl">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-500 animate-spin-slow" />
            <h3 className="font-bold text-lg text-white">إعدادات إعلانات Google AdSense</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-850 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSave} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Ad Mode Toggle */}
          <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-800/80">
            <div>
              <p className="font-bold text-sm text-white">وضع المحاكاة (المعرض التجريبي)</p>
              <p className="text-xs text-gray-400 mt-0.5">يعرض إعلانات ألعاب تفاعلية جميلة خالية من الأخطاء لتفادي حظر الحساب.</p>
            </div>
            <button
              type="button"
              onClick={() => setLocalConfig(prev => ({ ...prev, isDemoMode: !prev.isDemoMode }))}
              className="text-amber-500 hover:text-amber-400 transition-colors cursor-pointer shrink-0"
            >
              {localConfig.isDemoMode ? (
                <ToggleRight className="w-12 h-12 text-emerald-500" />
              ) : (
                <ToggleLeft className="w-12 h-12 text-gray-500" />
              )}
            </button>
          </div>

          {/* AdSense Credentials */}
          {!localConfig.isDemoMode ? (
            <div className="space-y-4 animate-slide-up">
              <div className="bg-amber-500/10 border border-amber-500/20 p-3.5 rounded-xl text-xs text-amber-300 flex gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  تنبيه: لاستخدام الإعلانات الحقيقية، تأكد من إدراج نطاق موقعك الحالي في لوحة تحكم AdSense الخاصة بك والموافقة عليه قبل ظهور الإعلانات المباشرة.
                </p>
              </div>

              {/* Publisher ID */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-300">
                  رقم معرف الناشر (Publisher ID)
                </label>
                <input
                  type="text"
                  placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                  value={localConfig.client}
                  onChange={e => setLocalConfig(prev => ({ ...prev, client: e.target.value }))}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              {/* Slot Top */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-300">
                  معرف الوحدة الإعلانية العلوية (Top Slot ID)
                </label>
                <input
                  type="text"
                  placeholder="XXXXXXXXXX"
                  value={localConfig.slotTop}
                  onChange={e => setLocalConfig(prev => ({ ...prev, slotTop: e.target.value }))}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              {/* Slot Side */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-300">
                  معرف الوحدة الإعلانية الجانبية (Sidebar Slot ID)
                </label>
                <input
                  type="text"
                  placeholder="XXXXXXXXXX"
                  value={localConfig.slotSide}
                  onChange={e => setLocalConfig(prev => ({ ...prev, slotSide: e.target.value }))}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              {/* Slot Bottom */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-300">
                  معرف الوحدة الإعلانية السفلية (Bottom Slot ID)
                </label>
                <input
                  type="text"
                  placeholder="XXXXXXXXXX"
                  value={localConfig.slotBottom}
                  onChange={e => setLocalConfig(prev => ({ ...prev, slotBottom: e.target.value }))}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3.5">
              <div className="flex items-center gap-2 text-emerald-400">
                <Check className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm">وضع المحاكاة نشط بنجاح</h4>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                في هذا الوضع، يتم تعويض وحدات الإعلانات الحقيقية بمحاكاة تفاعلية جميلة صممت خصيصاً لتبدو مثل إعلانات الألعاب الحقيقية. تمنحك هذه المحاكاة فكرة دقيقة جداً عن جودة تجربة المستخدم ومواضع الإعلانات الفعالة دون الحاجة لربط حساب AdSense الفعلي فوراً.
              </p>
            </div>
          )}

          {/* Quick Guide */}
          <div className="border-t border-slate-800 pt-4 space-y-2.5 text-xs text-gray-400">
            <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-amber-500" />
              كيف أحصل على معرفات إعلانات Google؟
            </h4>
            <ol className="list-decimal list-inside space-y-1.5 pr-1 leading-relaxed">
              <li>سجل الدخول إلى حسابك في <span className="text-white">Google AdSense</span>.</li>
              <li>توجه إلى قائمة <span className="text-white">الإعلانات (Ads)</span> ثم حدد <span className="text-white">حسب الوحدة الإعلانية (By ad unit)</span>.</li>
              <li>قم بإنشاء وحدة إعلانية جديدة من نوع <span className="text-white">الصورية (Display ads)</span>.</li>
              <li>انسخ رقم الناشر <span className="text-white">client</span> (الذي يبدأ بـ ca-pub-) ومُعرّف الوحدة <span className="text-white">slot</span> وقم بوضعهم هنا.</li>
            </ol>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-semibold text-gray-400 hover:text-white hover:bg-slate-850 rounded-xl transition-all cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-amber-500/10 transition-all cursor-pointer"
            >
              {isSaved ? (
                <>
                  <Check className="w-4 h-4 text-emerald-950" />
                  تم الحفظ بنجاح
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  حفظ التعديلات
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
