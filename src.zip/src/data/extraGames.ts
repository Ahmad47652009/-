import { Game } from '../types';

export const EXTRA_GAMES: Game[] = [
  // 1. DODGE (Arcade Dodge-and-Collect)
  {
    id: 'extra_dodge_1',
    titleAr: 'مغامرة كبسولة الفضاء',
    titleEn: 'Space Capsule Adventure',
    descAr: 'تحكم في كبسولة الفضاء لتفادي الحطام الكوني المتساقط واجمع طاقة النجوم اللامعة لتحقيق أعلى نقاط.',
    descEn: 'Pilot your space capsule to dodge space debris and collect stellar energy for max points.',
    icon: '🚀',
    categoryAr: 'فضاء وخيال',
    categoryEn: 'Space & Sci-Fi',
    difficulty: 'متوسط',
    isCustom: true,
    authorName: 'فريق التطوير الفاخر',
    gameType: 'dodge'
  },

  // 2. FLAPPY (Gravity Jumper)
  {
    id: 'extra_flappy_1',
    titleAr: 'تحليق طائر الفينيق',
    titleEn: 'Flappy Phoenix',
    descAr: 'طِر بضربات أجنحة طائر الفينيق الأسطوري وتخطى الأعمدة البركانية المتوهجة دون لمسها لتحافظ على خلودك.',
    descEn: 'Flap the wings of the legendary Phoenix, avoiding molten lava pillars to maintain your flame.',
    icon: '🦅',
    categoryAr: 'أركيد ومغامرة',
    categoryEn: 'Arcade & Adventure',
    difficulty: 'صعب',
    isCustom: true,
    authorName: 'مروض الأساطير',
    gameType: 'flappy'
  },

  // 3. SHOOTER (Space Shooter)
  {
    id: 'extra_shooter_1',
    titleAr: 'غزاة المجرة المظلمة',
    titleEn: 'Galactic Invaders',
    descAr: 'تحكم بمركبتك الحربية وأطلق قذائف البلازما لتدمير جحافل الكائنات الفضائية الغازية قبل أن تصل لسطح كوكبك.',
    descEn: 'Pilot a starfighter and blast incoming alien swarms with intense plasma fire.',
    icon: '👾',
    categoryAr: 'فضاء وخيال',
    categoryEn: 'Space & Sci-Fi',
    difficulty: 'صعب',
    isCustom: true,
    authorName: 'جنرال المجرة',
    gameType: 'shooter'
  },

  // 4. CATCHER (Catch Items in Basket)
  {
    id: 'extra_catcher_1',
    titleAr: 'سلة الفواكه السعيدة',
    titleEn: 'Fruit Basket Frenzy',
    descAr: 'التقط التفاح والبرتقال والموز الطازج المتساقط من الأشجار، وتجنب التقاط الحشرات الفاسدة.',
    descEn: 'Move your basket to harvest ripe apples and delicious fruits, whilst avoiding poisoned caterpillars.',
    icon: '🍎',
    categoryAr: 'رياضة ومهارة',
    categoryEn: 'Sports & Skill',
    difficulty: 'سهل',
    isCustom: true,
    authorName: 'مزارع البستان السعيد',
    gameType: 'catcher'
  },

  // 5. CLICKER (Idle Tycoon)
  {
    id: 'extra_clicker_1',
    titleAr: 'عملاق الكعك الذهبي',
    titleEn: 'Golden Cookie Tycoon',
    descAr: 'انقر على الكعكة الذهبية لإنتاج ملايين البسكويت، واشترِ المخابز الآلية وفرن الجدة العملاق لمضاعفة أرباحك.',
    descEn: 'Click the big cookie to generate baked goods, hiring grandmas and buying automated factories.',
    icon: '🍪',
    categoryAr: 'كلاسيك ومحاكاة',
    categoryEn: 'Classic & Simulation',
    difficulty: 'سهل',
    isCustom: true,
    authorName: 'الملك السكري',
    gameType: 'clicker'
  },

  // 6. BREAKER (Brick Breaker)
  {
    id: 'extra_breaker_1',
    titleAr: 'كسار الطوب الكلاسيكي',
    titleEn: 'Retro Brick Breaker',
    descAr: 'تحدي تحطيم جدران الطوب الكلاسيكية! وجه المضرب واجعل الكرة ترتد لتدمر الكتل بالكامل وتجمع المكافآت.',
    descEn: 'Control the sliding paddle to bounce the metallic ball and shatter rows of high-density bricks.',
    icon: '🧱',
    categoryAr: 'كلاسيك ومحاكاة',
    categoryEn: 'Classic & Simulation',
    difficulty: 'متوسط',
    isCustom: true,
    authorName: 'أستوديو الذكريات القديمة',
    gameType: 'breaker'
  },

  // 7. STACKER (Tower Stacker)
  {
    id: 'extra_stacker_1',
    titleAr: 'بناء ناطحة السحاب',
    titleEn: 'Sky High Tower Builder',
    descAr: 'اضغط في الوقت المناسب لإسقاط طوابق البناية فوق بعضها بدقة لبناء أطول ناطحة سحاب حديثة في وسط المدينة.',
    descEn: 'Drop sliding high-rise block levels on top of each other. Cut blocks if you align them poorly!',
    icon: '🏢',
    categoryAr: 'رياضة ومهارة',
    categoryEn: 'Sports & Skill',
    difficulty: 'متوسط',
    isCustom: true,
    authorName: 'المهندس المعماري البارع',
    gameType: 'stacker'
  },

  // 8. WHACK (Whack-a-Mole)
  {
    id: 'extra_whack_1',
    titleAr: 'مطرقة الخلد المشاغب',
    titleEn: 'Whack-a-Mole Madness',
    descAr: 'اضرب حيوان الخلد المشاغب فور خروجه من جحره لتسجيل النقاط، وتفادى ضرب حيوانات القنفذ الشائكة المؤذية.',
    descEn: 'Tap the fast-popping mischievous moles. Avoid clicking thorny hedgehogs to protect your score!',
    icon: '🦫',
    categoryAr: 'سرعة وأكشن',
    categoryEn: 'Speed & Action',
    difficulty: 'متوسط',
    isCustom: true,
    authorName: 'حارس الحقل المجد',
    gameType: 'whack'
  },

  // 9. MATH (Speed Math Challenge)
  {
    id: 'extra_math_1',
    titleAr: 'ساحر الحساب الذهني',
    titleEn: 'Mental Math Wizard',
    descAr: 'اختبر ذكائك وسرعتك الذهنية بحل مسائل الجمع والطرح والضرب السريعة قبل انتهاء مؤقت الثواني القاتل.',
    descEn: 'Crack mental math arithmetic equations under intense ticking time pressure to raise your IQ.',
    icon: '🧙‍♂️',
    categoryAr: 'ذكاء وألغاز',
    categoryEn: 'Brain & Puzzle',
    difficulty: 'متوسط',
    isCustom: true,
    authorName: 'عبقري الرياضيات المتميز',
    gameType: 'math'
  },

  // 10. COLOR (Color Swapper / Matching)
  {
    id: 'extra_color_1',
    titleAr: 'مبدل الألوان الذكي',
    titleEn: 'Neon Color Swap',
    descAr: 'تتحرك كرتك وتغير لونها باستمرار! اضغط لتبديل الألوان لتتوافق بدقة مع لون الحواجز التي تمر من خلالها بذكاء.',
    descEn: 'Toggle your dynamic orb color to match colored shields before collision to pass cleanly through.',
    icon: '🎨',
    categoryAr: 'سرعة وأكشن',
    categoryEn: 'Speed & Action',
    difficulty: 'متوسط',
    isCustom: true,
    authorName: 'موزع طاقة قوس قزح',
    gameType: 'color'
  }
];
