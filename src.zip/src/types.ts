export type GameId = string;

export interface Comment {
  id: string;
  gameId: GameId;
  username: string;
  rating: number; // 1 to 5
  text: string;
  createdAt: string;
}

export interface Game {
  id: GameId;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  icon: string;
  categoryAr: string;
  categoryEn: string;
  difficulty: 'سهل' | 'متوسط' | 'صعب' | 'Easy' | 'Medium' | 'Hard';
  isCustom?: boolean;
  customUrl?: string; // Embedded iframe url (Scratch, itch.io, codepen, etc.)
  authorName?: string;
  gameType?: 'dodge' | 'flappy' | 'shooter' | 'catcher' | 'clicker' | 'breaker' | 'stacker' | 'whack' | 'math' | 'color';
}

export interface AdConfig {
  client: string; // e.g., ca-pub-XXXXXXXXXXXXXXXX
  slotTop: string;
  slotSide: string;
  slotBottom: string;
  isDemoMode: boolean;
}

export interface UserStats {
  snakeHighScore: number;
  memoryBestMoves: number;
  tictactoeWins: number;
  speedclickerHighScore: number;
}
