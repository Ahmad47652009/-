import React, { useState, useEffect } from 'react';
import { Game, GameId, AdConfig, UserStats, Comment } from './types';
import SnakeGame from './components/games/SnakeGame';
import MemoryGame from './components/games/MemoryGame';
import TicTacToe from './components/games/TicTacToe';
import SpeedClicker from './components/games/SpeedClicker';
import GoogleAd from './components/GoogleAd';
import AdSettings from './components/AdSettings';
import GameComments from './components/GameComments';
import CustomGameCanvas from './components/CustomGameCanvas';
import CustomGameModal from './components/CustomGameModal';
import OwnerAuthModal from './components/OwnerAuthModal';
import { EXTRA_GAMES } from './data/extraGames';

import {
  Gamepad2,
  Settings,
  HelpCircle,
  Share2,
  TrendingUp,
  Award,
  Zap,
  Flame,
  MousePointerClick,
  MonitorPlay,
  Heart,
  DollarSign,
  Star,
  Sparkles,
  PlusCircle,
  Trash2,
  Lock,
  Unlock,
  Key,
  Search,
  Filter,
  Users,
  Eye
} from 'lucide-react';

const GAMES: Game[] = [
  {
    id: 'snake',
    titleAr: 'الثعبان الكلاسيكي',
    titleEn: 'Classic Snake',
    descAr: 'التقط الكرات لتنمو وتتفادى الارتطام بالجدران وجسدك.',
    descEn: 'Collect red pellets to grow and avoid hitting boundaries or yourself.',
    icon: '🐍',
    categoryAr: 'أركيد',
    categoryEn: 'Arcade',
    difficulty: 'متوسط',
  },
  {
    id: 'memory',
    titleAr: 'مطابقة الرموز',
    titleEn: 'Memory Match',
    descAr: 'اختبر قوة ذاكرتك واكشف الأزواج المتطابقة بأقل حركات.',
    descEn: 'Test your memory and match duplicate icons in minimal moves.',
    icon: '🧩',
    categoryAr: 'ذكاء',
    categoryEn: 'Puzzle',
    difficulty: 'سهل',
  },
  {
    id: 'tictactoe',
    titleAr: 'إكس أو الذكية',
    titleEn: 'Tic-Tac-Toe',
    descAr: 'تحدّ الذكاء الاصطناعي أو العب مع صديقك محلياً على اللوحة.',
    descEn: 'Challenge our adaptive AI or play locally against a friend.',
    icon: '❌',
    categoryAr: 'استراتيجية',
    categoryEn: 'Strategy',
    difficulty: 'متوسط',
  },
  {
    id: 'speedclicker',
    titleAr: 'صائد النيازك',
    titleEn: 'Meteor Popper',
    descAr: 'فجّر النيازك المتساقطة بسرعة فائقة قبل تدمير الكوكب.',
    descEn: 'Tap and blast falling meteors at rapid speed before they crash.',
    icon: '☄️',
    categoryAr: 'أكشن وسرعة',
    categoryEn: 'Action',
    difficulty: 'صعب',
  },
];

export default function App() {
  const [activeGame, setActiveGame] = useState<GameId | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isOwner, setIsOwner] = useState<boolean>(() => {
    return localStorage.getItem('star_arcade_is_owner') === 'true';
  });
  const [isOwnerAuthOpen, setIsOwnerAuthOpen] = useState(false);
  
  // Real-time Traffic Counters (Online Players & Total Visitors)
  const [onlinePlayers, setOnlinePlayers] = useState<number>(1);
  const [totalVisitors, setTotalVisitors] = useState<number>(342912);

  // Game filters and lazy-loading pagination
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [visibleGamesCount, setVisibleGamesCount] = useState<number>(12);

  useEffect(() => {
    // Generate or retrieve persistent unique session ID
    let sessionId = localStorage.getItem('star_arcade_session_id');
    if (!sessionId) {
      sessionId = 'sess_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
      localStorage.setItem('star_arcade_session_id', sessionId);
    }

    // Check if we already registered this session as a visitor
    const hasVisited = localStorage.getItem('star_arcade_has_visited') === 'true';

    const sendHeartbeat = async () => {
      try {
        const response = await fetch('/api/heartbeat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            sessionId,
            isNew: !hasVisited,
          }),
        });
        if (response.ok) {
          const data = await response.json();
          if (data.onlinePlayers !== undefined) {
            setOnlinePlayers(data.onlinePlayers);
          }
          if (data.totalVisitors !== undefined) {
            setTotalVisitors(data.totalVisitors);
            // Mark session as visited locally so subsequent loads/heartbeats don't double-register
            localStorage.setItem('star_arcade_has_visited', 'true');
          }
        }
      } catch (error) {
        console.error('Error sending heartbeat to real-time stats backend:', error);
      }
    };

    // Send immediately on load
    sendHeartbeat();

    // Send periodically every 10 seconds to keep session alive and get real-time active users
    const interval = setInterval(sendHeartbeat, 10000);
    return () => clearInterval(interval);
  }, []);
  
  // AdSense configuration loaded from localStorage
  const [adConfig, setAdConfig] = useState<AdConfig>(() => {
    const saved = localStorage.getItem('star_arcade_ads_config');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Force upgrade to the user's real client if the old demo ID is active
        if (parsed.client === 'ca-pub-1234567890123456') {
          const upgraded = {
            client: 'ca-pub-1041636640907984',
            slotTop: '9563837270',
            slotSide: '9563837270',
            slotBottom: '9563837270',
            isDemoMode: false,
          };
          localStorage.setItem('star_arcade_ads_config', JSON.stringify(upgraded));
          return upgraded;
        }
        return parsed;
      } catch (e) {
        // Fallback to default
      }
    }
    return {
      client: 'ca-pub-1041636640907984',
      slotTop: '9563837270',
      slotSide: '9563837270',
      slotBottom: '9563837270',
      isDemoMode: false,
    };
  });

  // User Stats loaded from localStorage
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('star_arcade_stats');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback
      }
    }
    return {
      snakeHighScore: 0,
      memoryBestMoves: 0,
      tictactoeWins: 0,
      speedclickerHighScore: 0,
    };
  });

  // State for user-submitted custom games
  const [customGames, setCustomGames] = useState<Game[]>(() => {
    const saved = localStorage.getItem('star_arcade_custom_games');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback
      }
    }
    return [
      {
        id: 'custom_retro_example',
        titleAr: 'مغامرة كبسولة الفضاء',
        titleEn: 'Space Capsule Adventure',
        descAr: 'تحكم في كبسولة الفضاء بمفتاح أو لمس الشاشة لتفادي الحطام الكوني المتساقط وجمع بلورات الطاقة اللامعة!',
        descEn: 'Drive the space capsule to avoid cosmic debris and capture pure crystals!',
        icon: '🚀',
        categoryAr: 'مغامرات',
        categoryEn: 'Adventure',
        difficulty: 'متوسط',
        isCustom: true,
        authorName: 'المصمم كريم',
      }
    ];
  });

  const [isCustomGameModalOpen, setIsCustomGameModalOpen] = useState(false);

  const handleAddCustomGame = (newGame: Game) => {
    setCustomGames(prev => {
      const updated = [...prev, newGame];
      localStorage.setItem('star_arcade_custom_games', JSON.stringify(updated));
      return updated;
    });
  };

  const handleDeleteCustomGame = (id: string) => {
    setCustomGames(prev => {
      const updated = prev.filter(g => g.id !== id);
      localStorage.setItem('star_arcade_custom_games', JSON.stringify(updated));
      return updated;
    });
    if (activeGame === id) {
      setActiveGame(null);
    }
  };

  const allGames = [...GAMES, ...EXTRA_GAMES, ...customGames];

  // Save Config changes
  const handleUpdateAdConfig = (newConfig: AdConfig) => {
    setAdConfig(newConfig);
    localStorage.setItem('star_arcade_ads_config', JSON.stringify(newConfig));
  };

  // Save Stats changes
  const handleUpdateStats = (newStats: Partial<UserStats>) => {
    setStats(prev => {
      const updated = { ...prev, ...newStats };
      localStorage.setItem('star_arcade_stats', JSON.stringify(updated));
      return updated;
    });
  };

  // User comments loaded from localStorage with default seeds
  const [comments, setComments] = useState<Comment[]>(() => {
    const saved = localStorage.getItem('star_arcade_comments');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback
      }
    }
    return [
      {
        id: 'c1',
        gameId: 'snake',
        username: 'خالد الغامدي',
        rating: 5,
        text: 'لعبة رائعة جداً تعيد ذكريات الطفولة الجميلة! التحكم سلس للغاية والسنايك يتحرك باستجابة سريعة.',
        createdAt: '٢٠٢٦/٠٧/٠٤',
      },
      {
        id: 'c2',
        gameId: 'snake',
        username: 'مريم علي',
        rating: 4,
        text: 'ممتعة جداً ومسلية، واجهت بعض الصعوبة في البداية لتجنب الاصطدام ولكن تعودت عليها.',
        createdAt: '٢٠٢٦/٠٧/٠٥',
      },
      {
        id: 'c3',
        gameId: 'memory',
        username: 'سارة محمد',
        rating: 5,
        text: 'لعبة مطابقة مذهلة وتصميم الأيقونات رائع ومريح للعين والذاكرة بصرياً.',
        createdAt: '٢٠٢٦/٠٧/٠٣',
      },
      {
        id: 'c4',
        gameId: 'tictactoe',
        username: 'عمر الفاروق',
        rating: 5,
        text: 'الذكاء الاصطناعي قوي ومحترف فعلاً! استمتعت جداً بالتحدي ومحاولة كسب اللعبة.',
        createdAt: '٢٠٢٦/٠٧/٠٤',
      },
      {
        id: 'c5',
        gameId: 'speedclicker',
        username: 'يوسف العتيبي',
        rating: 5,
        text: 'سريعة ومحمسة! تزيد الأدرينالين وممتازة لاختبار سرعة رد الفعل.',
        createdAt: '٢٠٢٦/٠٧/٠٥',
      },
    ];
  });

  const handleAddComment = (newCommentData: Omit<Comment, 'id' | 'createdAt'>) => {
    const formatter = new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    const newComment: Comment = {
      ...newCommentData,
      id: `comment_${Date.now()}`,
      createdAt: formatter.format(new Date()),
    };
    setComments(prev => {
      const updated = [newComment, ...prev];
      localStorage.setItem('star_arcade_comments', JSON.stringify(updated));
      return updated;
    });
  };

  const handleDeleteComment = (id: string) => {
    setComments(prev => {
      const updated = prev.filter(c => c.id !== id);
      localStorage.setItem('star_arcade_comments', JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-gray-100 flex flex-col font-sans select-none" dir="rtl" id="app-root">
      
      {/* 1. Header Banner Ad Block */}
      <div className="w-full bg-black/40 py-3 px-4 flex justify-center border-b border-slate-900">
        <GoogleAd
          client={adConfig.client}
          slot={adConfig.slotTop}
          adType="leaderboard"
          isDemoMode={adConfig.isDemoMode}
        />
      </div>

      {/* Navigation Bar */}
      <header className="sticky top-0 z-40 backdrop-blur-lg bg-slate-900/50 border-b border-indigo-500/30 px-4 md:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setActiveGame(null)}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-all">
              <Gamepad2 className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <h1 className="font-black text-2xl tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">عالم الألعاب</h1>
              <p className="text-[10px] text-purple-400 font-bold tracking-wide">ألعاب مجانية ومساحات إعلانية</p>
            </div>
          </button>
        </div>

        {/* Global actions and metrics */}
        <div className="flex items-center gap-3">
          {activeGame && (
            <button
              onClick={() => setActiveGame(null)}
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-gray-300 hover:text-white px-4 py-2 rounded-xl border border-slate-700 transition-colors cursor-pointer"
            >
              الرئيسية
            </button>
          )}

          {isOwner ? (
            <div className="flex items-center gap-2">
              <span className="hidden md:inline-flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] px-2.5 py-1.5 rounded-full font-bold">
                <Unlock className="w-3 h-3" />
                <span>وضع المالك</span>
              </span>
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="flex items-center gap-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-full shadow-lg shadow-indigo-500/20 transition-all cursor-pointer"
              >
                <Settings className="w-4 h-4" />
                <span>لوحة الإعلانات</span>
              </button>
              <button
                onClick={() => {
                  setIsOwner(false);
                  localStorage.removeItem('star_arcade_is_owner');
                }}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-red-400 rounded-full transition-all cursor-pointer"
                title="خروج من وضع المالك (قفل)"
              >
                <Lock className="w-4 h-4" />
              </button>
            </div>
          ) : null}
        </div>
      </header>

      {/* Main Layout Block */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 flex flex-col gap-8">
        
        {/* If Active Game is selected, show Game Station flanked by Skyscraper Ads */}
        {activeGame ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left/Right Skyscraper Ads (Large screens only) */}
            <div className="hidden lg:block lg:col-span-3 h-full">
              <div className="sticky top-24">
                <GoogleAd
                  client={adConfig.client}
                  slot={adConfig.slotSide}
                  adType="skyscraper"
                  isDemoMode={adConfig.isDemoMode}
                />
              </div>
            </div>

            {/* Main Active Game Panel */}
            <div className="lg:col-span-6 flex flex-col gap-6">
              <div className="bg-slate-900 rounded-[40px] border-4 border-indigo-500/20 p-6 shadow-xl flex flex-col gap-6 relative">
                
                {/* Back to Hub controller */}
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                  <div>
                    <h2 className="text-xl font-black text-white flex items-center gap-2">
                      <span>{allGames.find(g => g.id === activeGame)?.titleAr}</span>
                      {allGames.find(g => g.id === activeGame)?.isCustom && (
                        <span className="bg-indigo-500/20 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-500/10">
                          لعبة مخصصة
                        </span>
                      )}
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {allGames.find(g => g.id === activeGame)?.descAr}
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveGame(null)}
                    className="px-4 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-750 text-gray-200 rounded-xl transition-all cursor-pointer"
                  >
                    ← عودة للرئيسية
                  </button>
                </div>

                {/* Game View Router */}
                <div className="w-full py-2">
                  {activeGame === 'snake' && (
                    <SnakeGame
                      highScore={stats.snakeHighScore}
                      onUpdateHighScore={(score) => handleUpdateStats({ snakeHighScore: score })}
                    />
                  )}
                  {activeGame === 'memory' && (
                    <MemoryGame
                      bestMoves={stats.memoryBestMoves}
                      onUpdateBestMoves={(moves) => handleUpdateStats({ memoryBestMoves: moves })}
                    />
                  )}
                  {activeGame === 'tictactoe' && (
                    <TicTacToe
                      wins={stats.tictactoeWins}
                      onUpdateWins={(wins) => handleUpdateStats({ tictactoeWins: wins })}
                    />
                  )}
                  {activeGame === 'speedclicker' && (
                    <SpeedClicker
                      highScore={stats.speedclickerHighScore}
                      onUpdateHighScore={(score) => handleUpdateStats({ speedclickerHighScore: score })}
                    />
                  )}
                  {allGames.find(g => g.id === activeGame)?.isCustom && (
                    <CustomGameCanvas game={allGames.find(g => g.id === activeGame)!} />
                  )}
                </div>

                {/* Game Bottom banner advertisement placeholder */}
                <div className="border-t border-slate-800/80 pt-6 mt-2">
                  <GoogleAd
                    client={adConfig.client}
                    slot={adConfig.slotBottom}
                    adType="leaderboard"
                    isDemoMode={adConfig.isDemoMode}
                  />
                </div>

              </div>

              {/* Game Comments and Ratings */}
              <GameComments
                gameId={activeGame}
                comments={comments}
                onAddComment={handleAddComment}
                onDeleteComment={handleDeleteComment}
              />
            </div>

            {/* Right/Left Skyscraper Ads (Large screens only) */}
            <div className="hidden lg:block lg:col-span-3 h-full">
              <div className="sticky top-24">
                <GoogleAd
                  client={adConfig.client}
                  slot={adConfig.slotSide}
                  adType="skyscraper"
                  isDemoMode={adConfig.isDemoMode}
                />
              </div>
            </div>

          </div>
        ) : (
          // Main Dashboard / Game Showcase view
          <div className="space-y-8 animate-fade-in">
            
            {/* App Hero Introduction banner */}
            <div className="relative rounded-[40px] overflow-hidden bg-gradient-to-r from-purple-900 to-indigo-900 border-4 border-indigo-500/20 p-6 md:p-10 flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl">
              {isOwner ? (
                <div className="space-y-4 max-w-xl text-right">
                  <div className="inline-flex items-center gap-1.5 bg-red-600 text-white px-3 py-1 rounded text-[10px] font-black uppercase">
                    <Flame className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
                    منصة ألعاب متكاملة للربح من جوجل أدسنس
                  </div>
                  <h2 className="text-2xl md:text-4xl font-black text-white leading-tight">
                    العب مجاناً وحقّق أرباحاً مع <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">Google AdSense</span>
                  </h2>
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed">
                    تتميز المنصة بتصميم عصري سريع الاستجابة لتنسيقات الإعلانات المختلفة. يمكنك استبدال معرف الناشر ومعرفات الوحدات الإعلانية ببياناتك الحقيقية لبدء تحقيق عوائد مالية فوراً من زيارات المستخدمين!
                  </p>
                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <button
                      onClick={() => setIsSettingsOpen(true)}
                      className="px-8 py-3 bg-indigo-500 hover:bg-indigo-400 rounded-2xl font-black text-sm transition-all transform active:scale-95 text-white cursor-pointer"
                    >
                      تخصيص معرفات الإعلانات الخاصة بي
                    </button>
                    <a
                      href="#adsense-guide"
                      className="bg-slate-800/80 hover:bg-slate-700 text-white font-semibold px-5 py-2.5 rounded-xl transition-all text-xs border border-slate-700"
                    >
                      دليل التكامل السريع
                    </a>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 max-w-xl text-right">
                  <div className="inline-flex items-center gap-1.5 bg-indigo-600/30 text-indigo-300 border border-indigo-500/20 px-3 py-1 rounded text-[10px] font-black uppercase">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
                    عالم ألعاب الويب التفاعلية والمجانية 🎮
                  </div>
                  <h2 className="text-2xl md:text-4xl font-black text-white leading-tight">
                    استمتع بـ <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">أقوى الألعاب الكلاسيكية</span> والمخصصة مجاناً!
                  </h2>
                  <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                    أهلاً بك في منصتنا الترفيهية الفاخرة. استمتع بمجموعة رائعة من الألعاب الكلاسيكية الخفيفة مثل الثعبان، الذاكرة، وXO. كما يمكنك تصميم لعبتك الخاصة أو إدراج روابط Scratch و HTML5 ونشرها ليلعبها الجميع فوراً!
                  </p>
                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <button
                      onClick={() => setIsCustomGameModalOpen(true)}
                      className="px-8 py-3 bg-indigo-600 hover:bg-indigo-550 rounded-2xl font-black text-xs transition-all transform active:scale-95 text-white cursor-pointer shadow-lg shadow-indigo-500/20"
                    >
                      أنشئ وانشر لعبتك الخاصة 🚀
                    </button>
                    <button
                      onClick={() => {
                        const element = document.getElementById('games-grid-section');
                        if (element) {
                          element.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="bg-slate-800/80 hover:bg-slate-705 text-slate-300 font-bold px-5 py-2.5 rounded-xl transition-all text-xs border border-slate-700 cursor-pointer"
                    >
                      تصفح الألعاب المتاحة
                    </button>
                  </div>
                </div>
              )}

              {/* Graphic stats card in Vibrant Palette theme (Aside style) */}
              <div className="w-full md:w-auto shrink-0 bg-indigo-600/10 border border-indigo-500/20 p-5 rounded-3xl space-y-4 shadow-xl min-w-[250px] text-right" dir="rtl">
                <h4 className="font-black text-xs text-indigo-400 uppercase tracking-wider border-b border-indigo-500/20 pb-2 flex items-center gap-1.5 justify-end">
                  <span>سجل نقاطك القياسي</span>
                  <Award className="w-4 h-4 text-yellow-400" />
                </h4>
                <div className="space-y-2.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">🐍 الثعبان الكلاسيكي:</span>
                    <span className="font-mono font-bold text-yellow-400">{stats.snakeHighScore}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">🧩 مطابقة الرموز:</span>
                    <span className="font-mono font-bold text-yellow-400">{stats.memoryBestMoves ? `${stats.memoryBestMoves} حركة` : '-'}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">❌ إكس أو ضد الذكاء:</span>
                    <span className="font-mono font-bold text-yellow-400">{stats.tictactoeWins} فوز</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">☄️ صائد النيازك:</span>
                    <span className="font-mono font-bold text-yellow-400">{stats.speedclickerHighScore}</span>
                  </div>
                </div>

                <div className="border-t border-indigo-500/20 pt-3 mt-1 space-y-2.5">
                  <h4 className="font-black text-[10px] text-indigo-400 uppercase tracking-wider flex items-center gap-1.5 justify-end">
                    <span>نشاط المنصة المباشر</span>
                    <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                  </h4>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">اللاعبين المتصلين:</span>
                    <span className="font-bold text-emerald-400 flex items-center gap-1.5 font-mono">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span>{onlinePlayers.toLocaleString('ar-EG')}</span>
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">إجمالي الزيارات:</span>
                    <span className="font-bold text-indigo-300 font-mono flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{totalVisitors.toLocaleString('ar-EG')}</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. Content Middle ad block */}
            <div className="w-full">
              <GoogleAd
                client={adConfig.client}
                slot={adConfig.slotTop}
                adType="leaderboard"
                isDemoMode={adConfig.isDemoMode}
              />
            </div>

            {/* Game Selector Section */}
            <div id="games-grid-section" className="space-y-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                  <h3 className="text-xl font-black text-white">اختر لغتك المفضلة وابدأ التحدي</h3>
                  <p className="text-xs text-slate-400">ألعاب خفيفة تفاعلية مصممة خصيصاً للهواتف وأجهزة الحاسوب</p>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => setIsCustomGameModalOpen(true)}
                    className="flex items-center gap-2 text-xs font-black bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-3 rounded-full shadow-lg shadow-indigo-500/20 transition-all cursor-pointer transform hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>أنشئ وانشر لعبتك الخاصة 🚀</span>
                  </button>
                  <span className="bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 text-[10px] px-3 py-2 rounded-full font-bold">
                    {allGames.length} ألعاب جاهزة للبث
                  </span>
                </div>
              </div>

              {/* Advanced Search and Horizontal Categories Filter Bar */}
              <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-3xl space-y-4 text-right" dir="rtl">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                  {/* Search Input */}
                  <div className="md:col-span-5 relative">
                    <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="ابحث عن ألعابك المفضلة..."
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setVisibleGamesCount(12); // Reset page size on search
                      }}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-2xl py-2 px-4 pr-10 text-xs text-white placeholder-slate-500 outline-none transition-all"
                    />
                  </div>

                  {/* Categories Label */}
                  <div className="md:col-span-7 flex items-center gap-2 justify-start overflow-x-auto no-scrollbar scroll-smooth">
                    <div className="shrink-0 text-slate-400 text-xs font-black flex items-center gap-1">
                      <Filter className="w-3.5 h-3.5 text-indigo-400" />
                      <span>الفئات:</span>
                    </div>
                    
                    <div className="flex gap-2 pb-1 pt-1">
                      {['الكل', 'أركيد ومغامرة', 'ذكاء وألغاز', 'سرعة وأكشن', 'فضاء وخيال', 'رياضة ومهارة', 'كلاسيك ومحاكاة', 'استراتيجية'].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => {
                            setSelectedCategory(cat);
                            setVisibleGamesCount(12); // Reset page size on category shift
                          }}
                          className={`shrink-0 px-3.5 py-1.5 rounded-full text-[11px] font-black transition-all cursor-pointer ${
                            selectedCategory === cat
                              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/10 scale-[1.02]'
                              : 'bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white border border-slate-800'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Filter Logic execution and Grid mapping */}
              {(() => {
                const filteredGames = allGames.filter(game => {
                  const matchesSearch = searchQuery.trim() === '' || 
                    game.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    game.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    game.descAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    game.descEn.toLowerCase().includes(searchQuery.toLowerCase());

                  if (!matchesSearch) return false;
                  if (selectedCategory === 'الكل') return true;

                  const cat = game.categoryAr;
                  if (selectedCategory === 'أركيد ومغامرة') {
                    return cat === 'أركيد' || cat === 'أركيد ومغامرة' || cat === 'مغامرات' || cat === 'أركيد و مغامرة';
                  }
                  if (selectedCategory === 'ذكاء وألغاز') {
                    return cat === 'ذكاء' || cat === 'ذكاء وألغاز' || cat === 'الذكاء و الألغاز';
                  }
                  if (selectedCategory === 'سرعة وأكشن') {
                    return cat === 'أكشن وسرعة' || cat === 'سرعة وأكشن' || cat === 'السرعة و الأكشن';
                  }
                  if (selectedCategory === 'فضاء وخيال') {
                    return cat === 'فضاء وخيال' || cat === 'الفضاء و الخيال';
                  }
                  if (selectedCategory === 'رياضة ومهارة') {
                    return cat === 'رياضة ومهارة' || cat === 'الرياضة و المهارة';
                  }
                  if (selectedCategory === 'كلاسيك ومحاكاة') {
                    return cat === 'كلاسيك ومحاكاة' || cat === 'المحاكاة و الكلاسيك' || cat === 'كلاسيك ومحاكاة';
                  }
                  return cat === selectedCategory;
                });

                const paginatedGames = filteredGames.slice(0, visibleGamesCount);

                if (filteredGames.length === 0) {
                  return (
                    <div className="bg-slate-900/40 rounded-3xl p-12 text-center border border-slate-800 space-y-3">
                      <div className="text-4xl text-slate-600">🔍</div>
                      <h4 className="font-bold text-white text-base">لم نجد أي ألعاب مطابقة لخيارات البحث!</h4>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">جرب كتابة عبارة أخرى أو تصفح الألعاب حسب فئتها المميزة في الأعلى.</p>
                    </div>
                  );
                }

                return (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      {paginatedGames.map((game, index) => {
                        const gradients = [
                          'from-emerald-500 to-teal-600',
                          'from-cyan-500 to-blue-600',
                          'from-purple-500 to-indigo-600',
                          'from-pink-500 to-rose-600'
                        ];
                        const gradient = gradients[index % gradients.length];
                        
                        const gameComments = comments.filter(c => c.gameId === game.id);
                        const totalRatings = gameComments.length;
                        const averageRating = totalRatings
                          ? (gameComments.reduce((sum, c) => sum + c.rating, 0) / totalRatings).toFixed(1)
                          : null;

                        return (
                          <div
                            key={game.id}
                            className="bg-slate-900 rounded-3xl p-4 border border-slate-800 flex flex-col justify-between hover:border-indigo-500/30 hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-300 group relative text-right"
                          >
                            <div className="space-y-3">
                              <div className={`h-24 bg-gradient-to-br ${gradient} rounded-2xl flex items-center justify-center text-3xl shadow-inner relative overflow-hidden`}>
                                <div className="absolute inset-0 bg-black/10 mix-blend-overlay"></div>
                                <span className="transform group-hover:scale-110 transition-transform duration-300 drop-shadow-md">{game.icon}</span>
                                
                                {game.isCustom && (
                                  <div className="absolute top-2 right-2 bg-indigo-600/90 text-white font-bold text-[8px] px-2 py-0.5 rounded-full uppercase tracking-wider backdrop-blur-sm border border-indigo-400/20">
                                    مخصصة
                                  </div>
                                )}
                              </div>
                              
                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md">
                                    {game.categoryAr}
                                  </span>
                                  <span className={`text-[9px] font-semibold px-2 py-0.5 rounded-md ${
                                    game.difficulty === 'سهل' ? 'bg-emerald-500/10 text-emerald-400' :
                                    game.difficulty === 'متوسط' ? 'bg-amber-500/10 text-amber-400' :
                                    'bg-red-500/10 text-red-400'
                                  }`}>
                                    {game.difficulty}
                                  </span>
                                </div>

                                <div className="flex items-center gap-1 text-[11px] font-bold text-yellow-500/90 pt-1 justify-end">
                                  {averageRating ? (
                                    <>
                                      <Star className="w-3.5 h-3.5 fill-yellow-500 text-yellow-500" />
                                      <span>{averageRating}</span>
                                      <span className="text-slate-500 text-[10px] font-medium">({totalRatings} تقييم)</span>
                                    </>
                                  ) : (
                                    <>
                                      <Star className="w-3.5 h-3.5 text-slate-700" />
                                      <span className="text-slate-500 text-[10px] font-medium">لا توجد تقييمات</span>
                                    </>
                                  )}
                                </div>

                                <h4 className="font-bold text-base text-white pt-1 group-hover:text-indigo-400 transition-colors">
                                  {game.titleAr}
                                </h4>
                                {game.authorName && (
                                  <div className="text-[10px] text-slate-400 font-bold pb-1">
                                    بواسطة: <span className="text-indigo-400">{game.authorName}</span>
                                  </div>
                                )}
                                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                                  {game.descAr}
                                </p>
                              </div>
                            </div>

                            <div className="pt-4 mt-4 flex flex-col gap-2">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => setActiveGame(game.id)}
                                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-xs font-black text-slate-300 group-hover:bg-indigo-500 group-hover:text-white transition-all cursor-pointer shadow-sm active:scale-[0.98]"
                                >
                                  العب الآن ←
                                </button>
                                {game.isCustom && (
                                  <button
                                    onClick={() => handleDeleteCustomGame(game.id)}
                                    className="p-2.5 bg-red-500/10 hover:bg-red-500/20 hover:text-red-400 text-slate-400 rounded-xl transition-all cursor-pointer"
                                    title="حذف هذه اللعبة المخصصة"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Pagination or Load More controller */}
                    {filteredGames.length > visibleGamesCount && (
                      <div className="flex flex-col items-center justify-center pt-4 pb-6 space-y-2">
                        <span className="text-slate-500 text-xs font-bold">
                          نعرض {paginatedGames.length.toLocaleString('ar-EG')} من أصل {filteredGames.length.toLocaleString('ar-EG')} ألعاب متاحة
                        </span>
                        <button
                          onClick={() => setVisibleGamesCount(prev => prev + 12)}
                          className="px-8 py-3 bg-indigo-600/10 hover:bg-indigo-600 border border-indigo-500/20 hover:border-indigo-500 text-indigo-400 hover:text-white font-black text-xs rounded-full transition-all cursor-pointer shadow-sm active:scale-[0.98]"
                        >
                          عرض المزيد من الألعاب المتنوعة ⬇️
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            {/* Detailed Guide about AdSense Monetization */}
            {isOwner && (
              <section id="adsense-guide" className="bg-indigo-600/5 border border-indigo-500/20 p-6 md:p-8 rounded-3xl space-y-6">
                <div className="flex items-center gap-3 border-b border-indigo-500/10 pb-4">
                  <div className="w-10 h-10 rounded-lg bg-indigo-600/10 flex items-center justify-center border border-indigo-500/20">
                    <DollarSign className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">دليل تكامل إعلانات Google AdSense واستثمار موقعك</h3>
                    <p className="text-xs text-slate-400">تعرّف على كيفية ربح الأموال الحقيقية من تشغيل منصة الألعاب الخاصة بك</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm text-slate-300">
                  <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-2.5">
                    <div className="w-8 h-8 rounded-md bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">١</div>
                    <h4 className="font-bold text-white text-sm">التخصيص والتهيئة</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      انقر فوق "لوحة الإعلانات" في الجزء العلوي، وقم بتعطيل "وضع المحاكاة". الصق معرف الناشر (Publisher ID) الخاص بك ثم حدد معرفات الفتحات (Slots) لتتحول الإعلانات تلقائياً إلى خوادم Google المباشرة.
                    </p>
                  </div>

                  <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-2.5">
                    <div className="w-8 h-8 rounded-md bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">٢</div>
                    <h4 className="font-bold text-white text-sm">ملاءمة تصميم الويب ومكافحة حظر الإعلانات</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      تم تخطيط مواضع الإعلانات بشكل علمي لتزيد نسبة النقر (CTR) بأمان دون التأثير السلبي على متعة اللعب. في حال نشاط حظر الإعلانات (AdBlocker)، يعرض المحاكي إعلانات ألعاب بديلة مميزة للمحافظة على جاذبية المنصة.
                    </p>
                  </div>

                  <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-2.5">
                    <div className="w-8 h-8 rounded-md bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">٣</div>
                    <h4 className="font-bold text-white text-sm">شروط قبول Google AdSense</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      قم بشراء نطاق مخصص (Domain)، وتأكد من كتابة صفحة "سياسة الخصوصية" واتفاقية المستخدم. أضف ملف `ads.txt` الخاص بك في الخادم لتفادي فقدان الأرباح، ثم قدّم موقعك للمراجعة والموافقة الفورية.
                    </p>
                  </div>
                </div>
              </section>
            )}

          </div>
        )}

      </main>

      {/* Main bottom footer ad */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6 px-4 text-center mt-auto space-y-4">
        <div className="max-w-4xl mx-auto">
          <GoogleAd
            client={adConfig.client}
            slot={adConfig.slotBottom}
            adType="leaderboard"
            isDemoMode={adConfig.isDemoMode}
          />
        </div>
        
        {/* Ad bottom bar style from Vibrant Palette */}
        <div className="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center text-xs tracking-wide">
          <div className="flex flex-wrap gap-4 md:gap-8 justify-center items-center">
            <span className="flex items-center gap-1.5">
              <span>{onlinePlayers.toLocaleString('ar-EG')} لاعب متصل الآن 🎮</span>
            </span>
            <span className="opacity-50">|</span>
            <span className="flex items-center gap-1.5">
              <span>{totalVisitors.toLocaleString('ar-EG')} زائر للموقع 👁️</span>
            </span>
            <span className="opacity-50">|</span>
            <span className="hover:underline cursor-pointer">سياسة الخصوصية</span>
            <span className="opacity-50">|</span>
            <span className="hover:underline cursor-pointer">شروط الاستخدام</span>
            <span className="opacity-50">|</span>
            <button
              onClick={() => {
                if (isOwner) {
                  setIsSettingsOpen(true);
                } else {
                  setIsOwnerAuthOpen(true);
                }
              }}
              className="hover:underline flex items-center gap-1 cursor-pointer font-bold text-yellow-300"
            >
              <Key className="w-3.5 h-3.5" />
              <span>{isOwner ? 'لوحة المالك' : 'بوابة المالك'}</span>
            </button>
          </div>
        </div>
      </footer>

      {/* AdSense Settings Panel Overlay */}
      <AdSettings
        config={adConfig}
        onUpdateConfig={handleUpdateAdConfig}
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* User Custom Game Submission Modal */}
      <CustomGameModal
        isOpen={isCustomGameModalOpen}
        onClose={() => setIsCustomGameModalOpen(false)}
        onAddGame={handleAddCustomGame}
      />

      {/* Owner Authentication Modal */}
      <OwnerAuthModal
        isOpen={isOwnerAuthOpen}
        onClose={() => setIsOwnerAuthOpen(false)}
        onAuthSuccess={() => {
          setIsOwner(true);
          localStorage.setItem('star_arcade_is_owner', 'true');
          setIsSettingsOpen(true);
        }}
      />

    </div>
  );
}
